<?php 
require_once 'api.php';
$request=$_SERVER['QUERY_STRING'];
$http_type = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')) ? 'https://' : 'http://';
$recent_url=dirname($http_type.$_SERVER['SERVER_NAME'].$_SERVER["REQUEST_URI"]);
$mchid = 'a0e5b19a8b4047c88184412997a421d1';
$private_key = 'a0c76773b8ca44ac9fa5100f5675c95f';
if($_GET['out_trade_no']){
		try {
		 $data=array(
	            'mchid'     	=> $mchid,
	            'out_trade_no'  => $_GET['out_trade_no'],
	            'nonce_str' 	=> str_shuffle(time()),
	    	);
		$url = 'https://admin.xunhuweb.com/pay/query';
		$data['sign']	  = XH_Payment_Api::generate_xh_hash($data,$private_key);
	    $response   	  = XH_Payment_Api::http_post_json($url, json_encode($data));
		$result     	  = $response?json_decode($response,true):null;
	    if(isset($result['status'])&&$result['status']=='complete'){
	        	?>
				<html>
				<head>
				<meta charset="utf-8">
				<meta http-equiv="X-UA-Compatible" content="IE=edge">
				<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
				<meta name="applicable-device" content="pc,mobile">
				<link href="/favicon.ico" rel="shortcut icon"/>
				<title>XunhuPay - 支付体验中心</title>
				<script src="js/jquery-2.1.4.min.js"></script>
				<script src="js/qrcode.min.js"></script>
				<link rel="stylesheet" href="css/bootstrap.min.css"/>
				<link rel="stylesheet" href="css/style.css"/>
				<link rel="stylesheet" href="css/m_reset.css"/>
				</head>
				<body>
				<div class="container">
				   <div class="row">
				    <div class="col-lg-12 col-sx-12">
				        <div class="head">
				    <img src="https://www.xunhupay.com/wp-content/themes/hupijiao/images/logo.png" alt=""/><span class="head-title">体验Demo</span>
				</div>        <div class="content">
				            <div class="content-head">
				                <div class="order">
				                <span class="sleft">支付成功！</span>
				                <span class="sright">感谢您使用xunhupay移动支付</span>
				            </div>
				            </div>
				
				            <div class="step step2">
				                <ul class="steps clearfix">
				                    <li>选择商品</li>
				                    <li >确认付款</li>
				                    <li class="active">支付成功</li>
				
				                </ul>
				            </div>
				        </div>
				        <div class="foot">
				    <p>Copyright © 2018 XunhuPay All Rights Reserved</p>
				</div>    </div>
				
				</div>
				</div>
				</body>
				</html>
		<?php
	    	}else{
	    	echo "<script>setTimeout('window.loaction.reload()',1000);</script>";
	    		?>
				<html>
				<head>
				<meta charset="utf-8">
				<meta http-equiv="X-UA-Compatible" content="IE=edge">
				<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
				<meta name="applicable-device" content="pc,mobile">
				<link href="/favicon.ico" rel="shortcut icon"/>
				<title>XunhuPay - 支付体验中心</title>
				<script src="js/jquery-2.1.4.min.js"></script>
				<script src="js/qrcode.min.js"></script>
				<link rel="stylesheet" href="css/bootstrap.min.css"/>
				<link rel="stylesheet" href="css/style.css"/>
				<link rel="stylesheet" href="css/m_reset.css"/>
				</head>
				<body>
				
				<div class="container">
				   <div class="row">
				
				    <div class="col-lg-12 col-sx-12">
				        <div class="head">
				    <img src="https://www.xunhupay.com/wp-content/themes/hupijiao/images/logo.png" alt=""/><span class="head-title">体验Demo</span>
				</div>        <div class="content">
				            <div class="content-head">
				                <div class="order">
				                <span class="sleft">支付失败！</span>
				                <span class="sright">请重新发起支付(如果已经支付成功请刷新一下页面)</span>
				            </div>
				            </div>
				            <div class="step step2">
				                <ul class="steps clearfix">
				                    <li>选择商品</li>
				                    <li class="active">确认付款</li>
				                    <li >支付成功</li>
				
				                </ul>
				            </div>
				        </div>
				        <div class="foot">
				    <p>Copyright © 2018 XunhuPay All Rights Reserved</p>
				</div>   
				</div>
				</div>
				</div>
				</body>
				</html>
				<?php	
	    	}
		}catch (Exception $e){
			
		}
	}else{
		?>
		<html>
		<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
		<meta name="applicable-device" content="pc,mobile">
		<link href="/favicon.ico" rel="shortcut icon"/>
		<title>XunhuPay - 支付体验中心</title>
		<script src="js/jquery-2.1.4.min.js"></script>
		<script src="js/qrcode.min.js"></script>
		<link rel="stylesheet" href="css/bootstrap.min.css"/>
		<link rel="stylesheet" href="css/style.css"/>
		<link rel="stylesheet" href="css/m_reset.css"/>
		</head>
		<body>
		
		<div class="container">
		   <div class="row">
		
		    <div class="col-lg-12 col-sx-12">
		        <div class="head">
		    <img src="https://www.xunhupay.com/wp-content/themes/hupijiao/images/logo.png" alt=""/><span class="head-title">体验Demo</span>
		</div>        <div class="content">
		            <div class="content-head">
		                <div class="order">
		
		                <span class="sleft">支付成功！</span>
		                <span class="sright">感谢您使用xunhupay移动支付</span>
		            </div>
		            </div>
		
		            <div class="step step2">
		                <ul class="steps clearfix">
		                    <li>选择商品</li>
		                    <li >确认付款</li>
		                    <li class="active">下单成功</li>
		
		                </ul>
		            </div>
		        </div>
		        <div class="foot">
		    <p>Copyright © 2018 XunhuPay All Rights Reserved</p>
		</div>    </div>
		
		</div>
		</div>
		</body>
		</html>
	<?php
}