<?php 
$http_type = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')) ? 'https://' : 'http://';
$recent_url=dirname($http_type.$_SERVER['SERVER_NAME'].$_SERVER["REQUEST_URI"]);
?>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta name="applicable-device" content="pc,mobile">
<link href="/favicon.ico" rel="shortcut icon"/>
<title>XunhuPay - 支付体验中心</title>
<!-- <script src="js/sweetalert/sweetalert.min.js"></script> -->
<!-- <link rel="stylesheet" href="css/sweetalert.css"/> -->
<link rel="stylesheet" href="css/bootstrap.min.css"/>
<link rel="stylesheet" href="css/style.css"/>
<link rel="stylesheet" href="css/m_reset.css"/>
</head>
<body>

<div class="container">
   <div class="row">

    <div class="col-lg-12 col-sx-12">
        <div class="head">
    <img src="https://www.xunhupay.com/wp-content/themes/hupijiao/images/logo.png" alt=""/><span class="head-title">体验Demo</span>
</div>        <div class="content">
            <div class="content-head">
                <div class="order">

                <span class="sleft">订单编号: WC2018022351274</span>
                <span class="sright">收款商家: XunhuPay</span>
            </div>
            </div>

            <div class="step step2">
                <ul class="steps clearfix">
                    <li>选择商品</li>
                    <li class="active">确认付款</li>
                    <li>支付成功</li>

                </ul>
            </div>

            <div class="pay_amount">
                <span class="amount_text">支付金额:</span>
                <span class="amount font-red">￥0.01</span>
            </div>



            <div class="order" style="margin-top: 20px;margin-bottom: 5px;">
                <span class="address-title">请选择付款方式</span>
            </div>

            <div class="ways">
                <div class="borders wechat_pay" style="text-align: center">
                   <p>
                       <img src="images/wx_pay.svg" style="margin:0 auto;width:34px" alt=""/><span style="margin-left: 7px;font-size: 13px;color:#878787;">微信支付</span>
                   </p>
                </div>
                <div class="borders ali_pay">
                    <p><img src="images/alipay.svg" style="margin:0 auto;width:80px" alt=""/> </p>
                </div>
            </div>

            <div class="go-pay">
                <span style="margin-right: 10px">测试体验商品不会发货</span>
                <button class="buy-button" style="width: 100px;">立即支付</button>
            </div>
        </div>

        <div class="foot">
    <p>Copyright © 2018 XunhuPay All Rights Reserved</p>
</div>    </div>

</div>
</div>
<script src="js/jquery-2.1.4.min.js"></script>
<script type="text/javascript"></script>
<script>
    var flag = 0;
    var type = '';
    var orderid=<?php echo time(); ?>;
    $(document).ready(function(){ 
	        $('.wechat_pay').addClass('click_active');
	        $('.ali_pay').removeClass('click_active');
	        flag = 1;
	        type = 'wechat';
	});
    $('.wechat_pay').on('click',function () {
        $('.wechat_pay').addClass('click_active');
        $('.ali_pay').removeClass('click_active');
        flag = 1;
        type = 'wechat';
    })

    $('.ali_pay').on('click',function () {
        $('.ali_pay').addClass('click_active');
        $('.wechat_pay').removeClass('click_active');
        flag = 1;
        type = 'alipay';
    });

    $('.go-pay').on('click',function () {
        if(flag == 0) {
            swal('请先选择支付方式');
        } else {
            window.location.href = '/demo-pay/pay.php?amount=' + '0.01' + '&type=' + type+'&orderid='+orderid;
        }
    })

 $(document).ready(function(){ 
	window.view={
		query:function () {
	        $.ajax({
	            type: "POST",
	            url: "<?php echo $recent_url ?>/query.php?out_trade_no="+orderid,
	            timeout:6000,
	            cache:false,
	            dataType:'text',
	            success:function(e){
	            		if (e && e.indexOf('complete')!==-1) {
		                $('#weixin-notice').css('color','green').text('已支付成功，跳转中...');
	                    window.location.href = "<?php echo $recent_url.'/return.php' ?>";
	                    return;
	                }
	                setTimeout(function(){window.view.query();}, 2000);
	            },
	            error:function(){
	            	 setTimeout(function(){window.view.query();}, 2000);
	            }
	        });
	    }
	};
	window.view.query();
});
</script>
</body>
</html>
