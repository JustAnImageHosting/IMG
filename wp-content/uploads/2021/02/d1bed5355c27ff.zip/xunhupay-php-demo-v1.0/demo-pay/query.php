<?php
/*
**订单查询
*/
	require_once 'api.php';
	$request=$_SERVER['QUERY_STRING'];
	$http_type = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')) ? 'https://' : 'http://';
	$recent_url=dirname($http_type.$_SERVER['SERVER_NAME'].$_SERVER["REQUEST_URI"]);
	$mchid = 'a0e5b19a8b4047c88184412997a421d1';
	$private_key = 'a0c76773b8ca44ac9fa5100f5675c95f';
	parse_str($request,$array);
	$order_id= $_GET['out_trade_no'];
	if($order_id){
	try {
		 $data=array(
	            'mchid'     	=> $mchid,
	            'out_trade_no'  => $order_id,
	            'nonce_str' 	=> str_shuffle(time()),
	    	);
		$url = 'https://admin.xunhuweb.com/pay/query';
		$data['sign']	  = XH_Payment_Api::generate_xh_hash($data,$private_key);
	    $response   	  = XH_Payment_Api::http_post_json($url, json_encode($data));
		$result     	  = $response?json_decode($response,true):null;
		//file_put_contents(realpath(dirname(__FILE__)) . "/log.txt",json_encode($result)."\r\n",FILE_APPEND);
	    if(isset($result['status'])&&$result['status']=='complete'){
	        	var_dump($result); 
	    	}
		}catch (Exception $e){
			
		}
			return $order_id;
	}
	
?>