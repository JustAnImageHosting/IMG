

// 检测地址是http还是https来加载不同的腾讯腾讯企业 WPA OpenAPI 文档
// var ishttps = 'https:' == document.location.protocol ? true : false;
// if(ishttps){
//   document.write('<script charset="utf-8" src="https://wpa.b.qq.com/cgi/wpa.php"></script>');
// }else{
//   document.write('<script charset="utf-8" src="http://wpa.b.qq.com/cgi/wpa.php"></script>');
// }

