<?php
/*
**微信jsapi支付获取openid
*/
require_once 'api.php';

$request=$_SERVER['QUERY_STRING'];
$http_type = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')) ? 'https://' : 'http://';
$recent_url=dirname($http_type.$_SERVER['SERVER_NAME'].$_SERVER["REQUEST_URI"]);
$mchid = 'a0e5b19a8b4047c88184412997a421d1';
$private_key = 'a0c76773b8ca44ac9fa5100f5675c95f';
$data=array(
	            'mchid'     	=> $mchid,
	            'redirect_url'	=> $recent_url.'/jsapi.php'
        	);
        	if(XH_Payment_Api::is_wechat_app()){
	        	$url='https://admin.xunhuweb.com/pay/openid';
	        	$openid_url=XH_Payment_Api::data_link($url,$data);
	        	header("location:".htmlspecialchars_decode($openid_url,ENT_NOQUOTES));
	        	exit;
        	}
?>