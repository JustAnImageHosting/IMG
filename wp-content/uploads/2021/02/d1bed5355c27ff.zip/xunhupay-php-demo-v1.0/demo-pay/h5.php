 <?php 
	 require_once 'api.php';
	 $http_type = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')) ? 'https://' : 'http://';
 	 $recent_url=dirname($http_type.$_SERVER['SERVER_NAME'].$_SERVER["REQUEST_URI"]);
 	 $mchid = 'a0e5b19a8b4047c88184412997a421d1';
	 $private_key = 'a0c76773b8ca44ac9fa5100f5675c95f';
	 $redirect_url=$recent_url.'/return.php?out_trade_no='.$data['out_trade_no'];
	 $data=array(
            'mchid'     	=> $mchid,
            'out_trade_no'	=> $_GET['out_trade_no'],
            'type'  		=> 'wechat',
            'total_fee' 	=> '1',
            'body'  		=> '支付测试',
            'notify_url'	=> $recent_url.'/notify.php',
            'nonce_str' 	=> str_shuffle(time()),
            'trade_type'	=> 'WAP',
	        'wap_url'	  	=> $http_type.$_SERVER['SERVER_NAME'],//h5支付域名必须备案，然后找服务商绑定
	        'wap_name'		=> '迅虎网络'
        );
	 $url ='https://admin.xunhuweb.com/pay/payment';
	 $data['sign']       = XH_Payment_Api::generate_xh_hash($data,$private_key);
	 $response   		 = XH_Payment_Api::http_post_json($url, json_encode($data));
	 $result     		 = $response?json_decode($response,true):null;
	 if(!$result){
	     throw new Exception('Internal server error',500);
	 }
	 $sign       	  = XH_Payment_Api::generate_xh_hash($result,$private_key);
	 if(!isset( $result['sign'])|| $sign!=$result['sign']){
	     throw new Exception('Invalid sign!',40029);
	 }
	 if($result['return_code']!='SUCCESS'){
	  	 throw new Exception($result['err_msg'],$result['err_code']);
	 }
	 $url=$result['mweb_url'].'&redirect_url='.urlencode($redirect_url);
 ?>
 <html>
		<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1, user-scalable=yes">
		<link href="/favicon.ico" rel="shortcut icon"/>
		<title>XunhuPay - 支付体验中心</title>
		<script src="js/jquery-2.1.4.min.js"></script>
		<script src="js/qrcode.min.js"></script>
		<link rel="stylesheet" href="css/bootstrap.min.css"/>
		<link rel="stylesheet" href="css/style.css"/>
		<link rel="stylesheet" href="css/m_reset.css"/>
		</head>
		<body>
		
		<div class="container">
		   <div class="row">
		
		    <div class="col-lg-12 col-sx-12">
		        <div class="head">
		    <img src="https://www.xunhupay.com/wp-content/themes/hupijiao/images/logo.png" alt=""/><span class="head-title">体验Demo</span>
		</div>        <div class="content">
					<div id="weixin-notice">支付中。。。</div>
		        </div>
		        <div class="foot">
		    <p>Copyright © 2018 XunhuPay All Rights Reserved</p>
		</div>    </div>
		
		</div>
		</div>
     <script src="js/jquery-2.1.4.min.js"></script>
     <script type="text/javascript">
     (function($){
    		window.view={
				query:function () {
			        $.ajax({
			            type: "POST",
			            url: "<?php echo $recent_url.'/query.php?out_trade_no='.$out_trade_no ?>",
			            timeout:6000,
			            cache:false,
			            dataType:'text',
			            success:function(e){
			            		if (e && e.indexOf('complete')!==-1) {
    			                $('#weixin-notice').css('color','green').text('已支付成功，跳转中...');
    		                    window.location.href = "<?php echo $recent_url.'/return.php' ?>";
    		                    return;
    		                }else{
    		                	window.location.href = '<?php echo $url ?>';
    		                }
			                setTimeout(function(){window.view.query();}, 2000);
			            },
			            error:function(){
			            	 setTimeout(function(){window.view.query();}, 2000);
			            }
			        });
			    }
    		};
    		window.view.query();
    	})(jQuery);
    	</script>
	</body>
</html>