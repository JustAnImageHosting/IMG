<?php
/*
**发起支付
*/
require_once 'api.php';
$request=$_SERVER['QUERY_STRING']; 
$http_type = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')) ? 'https://' : 'http://';
$recent_url=dirname($http_type.$_SERVER['SERVER_NAME'].$_SERVER["REQUEST_URI"]);
$mchid = 'a0e5b19a8b4047c88184412997a421d1';
$private_key = 'a0c76773b8ca44ac9fa5100f5675c95f';
parse_str($request,$array);
try {    
    //创建订单支付编号
    $data=array(
            'mchid'     	=> $mchid,
            'out_trade_no'	=> $array['orderid'],
            'type'  		=> $array['type'],
            'total_fee' 	=> $array['amount']*100,
            'body'  		=> '支付测试',
            'notify_url'	=> $recent_url.'/notify.php',
            'nonce_str' 	=> str_shuffle(time())
        );
		$url ='https://admin.xunhuweb.com/pay/payment';
        if($data['type']=='wechat'){
        	//收银台支付
	        if(XH_Payment_Api::is_wechat_app()){
	         	 $data['redirect_url']=$recent_url.'/return.php';
	        	 $data['sign']     = XH_Payment_Api::generate_xh_hash($data,$private_key);
	        	 $pay_url     = XH_Payment_Api::data_link('https://admin.xunhuweb.com/pay/cashier', $data);
	        	 header("Location:". htmlspecialchars_decode($pay_url,ENT_NOQUOTES));
		    	 exit;
	        }
	        //h5支付
        	if(XH_Payment_Api::is_app_client()){
        		 $redirect_url=$recent_url.'/return.php?out_trade_no='.$data['out_trade_no'];
	        	 $data['trade_type'] = 'WAP';
	        	 $data['wap_url']    = $http_type.$_SERVER['SERVER_NAME'];//h5支付直接找服务商绑定,无需备案
	        	 $data['wap_name']   = '迅虎网络';
	        	 $data['sign']       = XH_Payment_Api::generate_xh_hash($data,$private_key);
		         $response   		 = XH_Payment_Api::http_post_json($url, json_encode($data));
		         $result     		 = $response?json_decode($response,true):null;
		         if(!$result){
		             throw new Exception('Internal server error',500);
		         }
		         $sign       	  = XH_Payment_Api::generate_xh_hash($result,$private_key);
		    	 if(!isset( $result['sign'])|| $sign!=$result['sign']){
		             throw new Exception('Invalid sign!',40029);
		         }
		         if($result['return_code']!='SUCCESS'){
		          	 throw new Exception($result['err_msg'],$result['err_code']);
		         }
		         $url =$result['mweb_url'].'&redirect_url='.urlencode($redirect_url);
		         ?>
		         <html>
					<head>
					<meta charset="utf-8">
					<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
					<meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1, user-scalable=yes">
					<link href="/favicon.ico" rel="shortcut icon"/>
					<title>XunhuPay - 支付体验中心</title>
					<script src="js/jquery-2.1.4.min.js"></script>
					<script src="js/qrcode.min.js"></script>
					<script src="js/sweetalert/sweetalert.min.js"></script>
					<link rel="stylesheet" href="css/bootstrap.min.css"/>
					<link rel="stylesheet" href="css/style.css"/>
					<link rel="stylesheet" href="css/m_reset.css"/>
					</head>
					<body>
					
					<div class="container">
					   <div class="row">
					
					    <div class="col-lg-12 col-sx-12">
					        <div class="head">
					    <img src="https://www.xunhupay.com/wp-content/themes/hupijiao/images/logo.png" alt=""/><span class="head-title">体验Demo</span>
					</div>        <div class="content">
								<div id="weixin-notice">支付中。。。</div>
					        </div>
					        <div class="foot">
					    <p>Copyright © 2018 XunhuPay All Rights Reserved</p>
					</div>    </div>
					
					</div>
					</div>
			     <script src="js/jquery-2.1.4.min.js"></script>
			     <script type="text/javascript">
			     
			     (function($){
			    		window.view={
							query:function () {
						        $.ajax({
						            type: "POST",
						            url: "<?php echo $recent_url.'/query.php?out_trade_no='.$data['out_trade_no'] ?>",
						            timeout:6000,
						            cache:false,
						            dataType:'text',
						            success:function(e){
						            		if (e && e.indexOf('complete')!==-1) {
			    			                $('#weixin-notice').css('color','green').text('已支付成功，跳转中...');
			    		                    window.location.href = "<?php echo $recent_url.'/return.php' ?>";
			    		                    return;
			    		                }else{
			    		                	window.location.href = "<?php echo $url ?>";
			    		                	return;
			    		                }
						                setTimeout(function(){window.view.query();}, 2000);
						            },
						            error:function(){
						            	 setTimeout(function(){window.view.query();}, 2000);
						            }
						        });
						    }
			    		};
			    		window.view.query();
			    	})(jQuery);
			    	</script>
				</body>
			</html>
		         <?php 
		         exit;
          	  }
	         	//扫码支付
		        $data['sign']     = XH_Payment_Api::generate_xh_hash($data,$private_key);
		        $response   	  = XH_Payment_Api::http_post_json($url, json_encode($data));
		        $result     	  = $response?json_decode($response,true):null;
		        if(!$result){
		            throw new Exception('Internal server error',500);
		        }
		        $sign       	  = XH_Payment_Api::generate_xh_hash($result,$private_key);
		        if(!isset( $result['sign'])|| $sign!=$result['sign']){
		            throw new Exception('Invalid sign!',40029);
		        }
		        if($result['return_code']!='SUCCESS'){
		        	throw new Exception($result['err_msg'],$result['err_code']);
		        }
		        $url =$result['code_url'];
		       ?>
	        	<html>
					<head>
					<meta charset="utf-8">
					<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
					<meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1, user-scalable=yes">
					<link href="/favicon.ico" rel="shortcut icon"/>
					<title>XunhuPay - 支付体验中心</title>
					<script src="js/jquery-2.1.4.min.js"></script>
					<script src="js/qrcode.min.js"></script>
					<script src="js/sweetalert/sweetalert.min.js"></script>
					<link rel="stylesheet" href="css/bootstrap.min.css"/>
					<link rel="stylesheet" href="css/style.css"/>
					<link rel="stylesheet" href="css/m_reset.css"/>
					</head>
					<body>
					
					<div class="container">
					   <div class="row">
					
					    <div class="col-lg-12 col-sx-12">
					        <div class="head">
					    <img src="https://www.xunhupay.com/wp-content/themes/hupijiao/images/logo.png" alt=""/><span class="head-title">体验Demo</span>
					</div>        <div class="content">
					            <div class="content-head">
					                <div>
					                    <span class="notice-head">请您尽快完成付款,以便订单及时处理</span>
					                    <p class="amount-container">
					                        <span class="amount_text">支付金额:</span>
					                        <span class="amount font-red">￥0.1</span>
					                    </p>
					                </div>
					            </div>
					
					            <div class="orders">
					                <span class="order-no">订单编号:
					                    <?php echo $data['out_trade_no'] ?>                </span>
					                <span class="order-time">订单时间: <?php echo date("Y/m/d") ?></span>
					            </div>
					
					
					            <div class="imgs row">
					                <div class="col-lg-6 qrcode same-height">
					                    <div class="code-box" style="height: 280px; width: 260px;">
					                        <div class="code" style="height: 245px;">
					                            <p class="code-container" id="wechat_qrcode">
					                                                            </p>
					                        </div>
					                                                    <div class="code_text">请使用微信扫一扫,扫描二维码支付</div>
					                                            </div>
					                </div>
					                <div class="col-lg-6 d-none d-md-block d-xl-block ">
					                                     <div class="d-flex align-items-center justify-content-center"><img src="<?php print $recent_url ?>/images/wedemo.png" style="width:200px;" alt=""></div>
					
					                </div>
					            </div>
					        </div>
					        <div class="foot">
					    <p>Copyright © 2018 XunhuPay All Rights Reserved</p>
					</div>    </div>
					
					</div>
					</div>
			     <script src="js/jquery-2.1.4.min.js"></script>
			      <script src="js/qrcode.js"></script>
			     <script type="text/javascript">
			     (function($){
			    		window.view={
							query:function () {
						        $.ajax({
						            type: "POST",
						            url: "<?php echo $recent_url.'/query.php?out_trade_no='.$data['out_trade_no'] ?>",
						            timeout:6000,
						            cache:false,
						            dataType:'text',
						            success:function(e){
						            		if (e && e.indexOf('complete')!==-1) {
			    			                $('#weixin-notice').css('color','green').text('已支付成功，跳转中...');
			    		                    window.location.href = "<?php echo $recent_url.'/return.php' ?>";
			    		                    return;
			    		                }
						                setTimeout(function(){window.view.query();}, 2000);
						            },
						            error:function(){
						            	 setTimeout(function(){window.view.query();}, 2000);
						            }
						        });
						    }
			    		};
			    		var qrcode = new QRCode(document.getElementById("wechat_qrcode"), {
			              width : 150,
			              height : 150
			            });
			            
			            <?php if(!empty($url)){
			              ?>
			              qrcode.makeCode("<?php print $url?>");
			              window.view.query();
			            <?php 
			            }?>
			    		
			    	})(jQuery);
			    	</script>
				</body>
			</html>
				<?php  
        }else{
        	if(XH_Payment_Api::is_app_client()){
        		// $data['redirect_url']=$recent_url.'/return.php';
        		$data['sign']	  = XH_Payment_Api::generate_xh_hash($data,$private_key);
	        	$pay_url          = XH_Payment_Api::data_link('https://admin.xunhuweb.com/alipaycashier', $data);
	        	header("Location:". htmlspecialchars_decode($pay_url,ENT_NOQUOTES));
		    	exit;
	        }
	        $data['sign']	  = XH_Payment_Api::generate_xh_hash($data,$private_key);
        	$response   	  = XH_Payment_Api::http_post_json($url, json_encode($data));
	        $result     	  = $response?json_decode($response,true):null;
	        if(!$result){
	            throw new Exception('Internal server error',500);
	        }
	        $sign       	  = XH_Payment_Api::generate_xh_hash($result,$private_key);
	        if(!isset( $result['sign'])|| $sign!=$result['sign']){
	            throw new Exception(__('Invalid sign!',XH_Wechat_Payment),40029);
	        }
	        if($result['return_code']!='SUCCESS'){
	        	throw new Exception($result['err_msg'],$result['err_code']);
	        }
	        $url =$result['code_url'];
        		 ?>
			<html>
				<head>
				<meta charset="utf-8">
				<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
				<meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1, user-scalable=yes">
				<link href="/favicon.ico" rel="shortcut icon"/>
				<title>XunhuPay - 支付体验中心</title>
				<script src="js/jquery-2.1.4.min.js"></script>
				<script src="js/qrcode.min.js"></script>
				<script src="js/sweetalert/sweetalert.min.js"></script>
				<link rel="stylesheet" href="css/bootstrap.min.css"/>
				<link rel="stylesheet" href="css/style.css"/>
				<link rel="stylesheet" href="css/m_reset.css"/>
				</head>
				<body>
				
				<div class="container">
				   <div class="row">
				
				    <div class="col-lg-12 col-sx-12">
				        <div class="head">
				    <img src="https://www.xunhupay.com/wp-content/themes/hupijiao/images/logo.png" alt=""/><span class="head-title">体验Demo</span>
				</div>        <div class="content">
				            <div class="content-head">
				                <div>
				                    <span class="notice-head">请您尽快完成付款,以便订单及时处理</span>
				                    <p class="amount-container">
				                        <span class="amount_text">支付金额:</span>
				                        <span class="amount font-red">￥0.1</span>
				                    </p>
				                </div>
				            </div>
				
				            <div class="orders">
				                <span class="order-no">订单编号:
				                    <?php echo $data['out_trade_no'] ?>                </span>
				                <span class="order-time">订单时间: <?php echo date("Y/m/d") ?></span>
				            </div>
				
				
				            <div class="imgs row">
				                <div class="col-lg-6 qrcode same-height">
				                    <div class="code-box" style="height: 280px; width: 260px;">
				                        <div class="code" style="height: 245px;">
				                            <p class="code-container" id="wechat_qrcode">
				                                                            </p>
				                        </div>
				                                                    <div class="code_text">请使用支付宝扫一扫,扫描二维码支付</div>
				                                            </div>
				                </div>
				                <div class="col-lg-6 d-none d-md-block d-xl-block ">
				                                     <div class="d-flex align-items-center justify-content-center"><img src="<?php print $recent_url ?>/images/alidemo.png" style="width:200px;" alt=""></div>
				
				                </div>
				            </div>
				        </div>
				        <div class="foot">
				    <p>Copyright © 2018 XunhuPay All Rights Reserved</p>
				</div>    </div>
				
				</div>
				</div>
		     <script src="js/jquery-2.1.4.min.js"></script>
		      <script src="js/qrcode.js"></script>
			 <script src="js/qrcode.min.js"></script>
		     <script type="text/javascript">
		     (function($){
		    		window.view={
						query:function () {
					        $.ajax({
					            type: "POST",
					            url: "<?php echo $recent_url.'/query.php?out_trade_no='.$data['out_trade_no'] ?>",
					            timeout:6000,
					            cache:false,
					            dataType:'text',
					            success:function(e){
					            		if (e && e.indexOf('complete')!==-1) {
		    			                $('#weixin-notice').css('color','green').text('已支付成功，跳转中...');
		    		                    window.location.href = "<?php echo $recent_url.'/return.php' ?>";
		    		                    return;
		    		                }
					                setTimeout(function(){window.view.query();}, 2000);
					            },
					            error:function(){
					            	 setTimeout(function(){window.view.query();}, 2000);
					            }
					        });
					    }
		    		};
		    		var qrcode = new QRCode(document.getElementById("wechat_qrcode"), {
		              width : 150,
		              height : 150
		            });
		            
		            <?php if(!empty($url)){
		              ?>
		              qrcode.makeCode("<?php print $url?>");
		              window.view.query();
		            <?php 
		            }?>
		    		
		    	})(jQuery);
		    	</script>
			</body>
		</html>
			<?php
        }
		  
    } catch (Exception $e) {
      exit;
}

?>