<?php 
require_once 'api.php';
$mchid = 'a0e5b19a8b4047c88184412997a421d1';
$private_key = 'a0c76773b8ca44ac9fa5100f5675c95f';
$data=(array)json_decode(file_get_contents('php://input'));
if(!$data){
	 exit('faild!');
}
// file_put_contents(realpath(dirname(__FILE__)) . "/log.txt",json_encode($data)."\r\n",FILE_APPEND);
$out_trade_no = isset($data['out_trade_no'])?$data['out_trade_no']:null;
$order_id=isset($data['order_id'])?$data['order_id']:null;
$hash =XH_Payment_Api::generate_xh_hash($data,$private_key);
if($data['sign']!=$hash){
    //签名验证失败
    echo '签名错误';exit;
}
if($data['status']=='complete'){
	/************商户业务处理******************/
    //TODO:此处处理订单业务逻辑,支付平台会多次调用本接口(防止网络异常导致回调失败等情况)
    //     请避免订单被二次更新而导致业务异常！！！
    //     if(订单未处理){
    //         处理订单....
    //      }
    //....
    //...
    /*************商户业务处理 END*****************/
}else{
	//处理未支付的情况	
}
	//以下是处理成功后输出，当支付平台接收到此消息后，将不再重复回调当前接口
print 'success';
exit;
?>