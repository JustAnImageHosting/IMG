<?php
/*
**微信jsapi支付
*/
require_once 'api.php';
$request=$_SERVER['QUERY_STRING'];
$http_type = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')) ? 'https://' : 'http://';
$recent_url=dirname($http_type.$_SERVER['SERVER_NAME'].$_SERVER["REQUEST_URI"]);
$mchid = 'a0e5b19a8b4047c88184412997a421d1';
$private_key = 'a0c76773b8ca44ac9fa5100f5675c95f';
parse_str($request,$array);
try {    
    //创建订单支付编号
    $data=array(
            'mchid'     	=> $mchid,
            'out_trade_no'	=> time(),
            'total_fee' 	=> '0.01'*100,
            'body'  		=> '微信jsapi支付测试',
            'notify_url'	=> $recent_url.'/notify.php',
            'nonce_str' 	=> str_shuffle(time())
        );
		$url ='https://admin.xunhuweb.com/pay/jsapi';
        		if(!$_GET['openid']){
        			exit('openid获取失败');
        			}
        			$data['openid']=$_GET['openid'];
        			unset($data['type']);
					$data['sign']     =XH_Payment_Api::generate_xh_hash($data,$private_key);
	        		$response   	  =XH_Payment_Api::http_post_json($url, json_encode($data));
					$result     	  =$response?json_decode($response,true):null;
					$jsapi			  =json_decode($result['jsapi']);
					if($jsapi){  
						?>
						 <p style="margin: 50px 0 0 0; text-align: center;">
							<img src="data:image/gif;base64,R0lGODlhEAAQAPQAAP///2R1cfb397jAvuzu7o+bmK63tWR1cZqlonqJhs3S0djc23GAfcPKyGd4dIWTkKSuq2R1cWR1cWR1cWR1cWR1cWR1cWR1cWR1cWR1cWR1cWR1cWR1cWR1cWR1cWR1cSH5BAkKAAAAIf4aQ3JlYXRlZCB3aXRoIGFqYXhsb2FkLmluZm8AIf8LTkVUU0NBUEUyLjADAQAAACwAAAAAEAAQAAAFdyAgAgIJIeWoAkRCCMdBkKtIHIngyMKsErPBYbADpkSCwhDmQCBethRB6Vj4kFCkQPG4IlWDgrNRIwnO4UKBXDufzQvDMaoSDBgFb886MiQadgNABAokfCwzBA8LCg0Egl8jAggGAA1kBIA1BAYzlyILczULC2UhACH5BAkKAAAALAAAAAAQABAAAAV2ICACAmlAZTmOREEIyUEQjLKKxPHADhEvqxlgcGgkGI1DYSVAIAWMx+lwSKkICJ0QsHi9RgKBwnVTiRQQgwF4I4UFDQQEwi6/3YSGWRRmjhEETAJfIgMFCnAKM0KDV4EEEAQLiF18TAYNXDaSe3x6mjidN1s3IQAh+QQJCgAAACwAAAAAEAAQAAAFeCAgAgLZDGU5jgRECEUiCI+yioSDwDJyLKsXoHFQxBSHAoAAFBhqtMJg8DgQBgfrEsJAEAg4YhZIEiwgKtHiMBgtpg3wbUZXGO7kOb1MUKRFMysCChAoggJCIg0GC2aNe4gqQldfL4l/Ag1AXySJgn5LcoE3QXI3IQAh+QQJCgAAACwAAAAAEAAQAAAFdiAgAgLZNGU5joQhCEjxIssqEo8bC9BRjy9Ag7GILQ4QEoE0gBAEBcOpcBA0DoxSK/e8LRIHn+i1cK0IyKdg0VAoljYIg+GgnRrwVS/8IAkICyosBIQpBAMoKy9dImxPhS+GKkFrkX+TigtLlIyKXUF+NjagNiEAIfkECQoAAAAsAAAAABAAEAAABWwgIAICaRhlOY4EIgjH8R7LKhKHGwsMvb4AAy3WODBIBBKCsYA9TjuhDNDKEVSERezQEL0WrhXucRUQGuik7bFlngzqVW9LMl9XWvLdjFaJtDFqZ1cEZUB0dUgvL3dgP4WJZn4jkomWNpSTIyEAIfkECQoAAAAsAAAAABAAEAAABX4gIAICuSxlOY6CIgiD8RrEKgqGOwxwUrMlAoSwIzAGpJpgoSDAGifDY5kopBYDlEpAQBwevxfBtRIUGi8xwWkDNBCIwmC9Vq0aiQQDQuK+VgQPDXV9hCJjBwcFYU5pLwwHXQcMKSmNLQcIAExlbH8JBwttaX0ABAcNbWVbKyEAIfkECQoAAAAsAAAAABAAEAAABXkgIAICSRBlOY7CIghN8zbEKsKoIjdFzZaEgUBHKChMJtRwcWpAWoWnifm6ESAMhO8lQK0EEAV3rFopIBCEcGwDKAqPh4HUrY4ICHH1dSoTFgcHUiZjBhAJB2AHDykpKAwHAwdzf19KkASIPl9cDgcnDkdtNwiMJCshACH5BAkKAAAALAAAAAAQABAAAAV3ICACAkkQZTmOAiosiyAoxCq+KPxCNVsSMRgBsiClWrLTSWFoIQZHl6pleBh6suxKMIhlvzbAwkBWfFWrBQTxNLq2RG2yhSUkDs2b63AYDAoJXAcFRwADeAkJDX0AQCsEfAQMDAIPBz0rCgcxky0JRWE1AmwpKyEAIfkECQoAAAAsAAAAABAAEAAABXkgIAICKZzkqJ4nQZxLqZKv4NqNLKK2/Q4Ek4lFXChsg5ypJjs1II3gEDUSRInEGYAw6B6zM4JhrDAtEosVkLUtHA7RHaHAGJQEjsODcEg0FBAFVgkQJQ1pAwcDDw8KcFtSInwJAowCCA6RIwqZAgkPNgVpWndjdyohACH5BAkKAAAALAAAAAAQABAAAAV5ICACAimc5KieLEuUKvm2xAKLqDCfC2GaO9eL0LABWTiBYmA06W6kHgvCqEJiAIJiu3gcvgUsscHUERm+kaCxyxa+zRPk0SgJEgfIvbAdIAQLCAYlCj4DBw0IBQsMCjIqBAcPAooCBg9pKgsJLwUFOhCZKyQDA3YqIQAh+QQJCgAAACwAAAAAEAAQAAAFdSAgAgIpnOSonmxbqiThCrJKEHFbo8JxDDOZYFFb+A41E4H4OhkOipXwBElYITDAckFEOBgMQ3arkMkUBdxIUGZpEb7kaQBRlASPg0FQQHAbEEMGDSVEAA1QBhAED1E0NgwFAooCDWljaQIQCE5qMHcNhCkjIQAh+QQJCgAAACwAAAAAEAAQAAAFeSAgAgIpnOSoLgxxvqgKLEcCC65KEAByKK8cSpA4DAiHQ/DkKhGKh4ZCtCyZGo6F6iYYPAqFgYy02xkSaLEMV34tELyRYNEsCQyHlvWkGCzsPgMCEAY7Cg04Uk48LAsDhRA8MVQPEF0GAgqYYwSRlycNcWskCkApIyEAOw==" width="16" height="16" alt="" /> 微信支付加载中，请稍候...
						</p>
						<script>
					    if (typeof WeixinJSBridge == "undefined") {
					        if (document.addEventListener) {
					            document.addEventListener('WeixinJSBridgeReady', onBridgeReady, false);
					        } else if (document.attachEvent) {
					            document.attachEvent('WeixinJSBridgeReady', onBridgeReady);
					            document.attachEvent('onWeixinJSBridgeReady', onBridgeReady);
					        }
					    }
					    function onBridgeReady() {
					        WeixinJSBridge.invoke(
					                'getBrandWCPayRequest', {
					                    // 以下参数通过上述接口返回的jsapi参数重获取
					                    // **************************
					                    "appId":	  '<?php echo $jsapi->appId ?>',
					                    "timeStamp":  '<?php echo $jsapi->timeStamp ?>',
					                    "nonceStr":   '<?php echo $jsapi->nonceStr ?>',
					                    "package":    '<?php echo $jsapi->package ?>',
					                    "signType":   '<?php echo $jsapi->signType ?>',
					                    "paySign":    '<?php echo $jsapi->paySign ?>',
					                    // **************************
					                },
					                function (res) {
					                    if (res.err_msg == "get_brand_wcpay_request:ok") {
					                    	location.href='<?php echo $recent_url.'/return.php' ?>';
					                    }
					                }
					        );
					    }
					</script>
				<?php
        		}
        		exit;
   } catch (Exception $e) {
      exit;
}
?>