<?php
namespace B2\Modules\Settings;

use B2\Modules\Common\User;

class Normal{

    //默认设置项
    public static $default_settings = array(
        'open_cache'=>1,
        'allow_register'=>1,
        'allow_cookie'=>0,
        'img_logo'=>'',
        'img_logo_white'=>'',
        'text_logo'=>'',
        'logo_width'=>'120',
        'default_imgs'=>[],
        'default_video_poster'=>'',
        'separator'=>'-',
        'money_symbol'=>'￥',
        'home_keywords'=>'',
        'home_description'=>'',
        'header_code'=>'',
        'footer_code'=>'',
        'check_type'=>'text',
        'build_phone_email'=>0,
        'phome_select'=>'aliyun',
        'accesskey_id'=>'',
        'access_key_secret'=>'',
        'sign_name'=>'',
        'template_code'=>'',
        'apikey'=>'',
        'yunpian_text'=>'',
        'tpl_id'=>'',
        'juhe_key'=>'',
        'site_key'=>'',
        'api_key'=>'',
        'zz_id'=>'',
        'zz_password'=>'',
        'tencent_id'=>'',
        'tencent_SmsSdkAppid'=>'',
        'tencent_Sign'=>'',
        //用户相关设置
        'user_avatar_open'=>1,
        'user_avatar_letter'=>1,
        'user_id_decode'=>0,
        'user_slug'=>'users',
        //创作设置
        'write_allow'=>1,
        'write_image_size'=>5,
        'write_video_size'=>50,
        'write_file_size'=>30,
        //社交登录
        'site_privacy'=>'',
        'site_terms'=>'',
        'wx_pc_secret'=>'',
        'wx_pc_key'=>'',
        'wx_gz_key'=>'',
        'wx_gz_secret'=>'',
        'qq_id'=>'',
        'qq_secret'=>'',
        'weibo_key'=>'',
        'weibo_secret'=>'',
        'wx_pc_open'=>0,
        'wx_gz_open'=>0,
        'qq_open'=>0,
        'weibo_open'=>0,
        'remove_category_tag'=>1,
        //积分奖励
        'credit_login'=>160,
        'credit_post'=>100,
        'credit_comment'=>20,
        'credit_comment_up'=>5,
        'credit_follow'=>5,
        'credit_post_up'=>10,
        'credit_qd'=>'50-200',
        'card_allow'=>1,
        'card_text'=>'',
        'credit_dh'=>38,
        'credit_qc'=>10,
        'credit_newsflashes'=>20,
        'tk_bs'=>3,
        //任务
        'task_post'=>2,
        'task_post_vote'=>4,
        'task_newsflashes'=>5,
        'task_comment'=>4,
        'task_comment_vote'=>6,
        'task_follow'=>2,
        'task_fans'=>2,
        'task_user_qq'=>100,
        'task_user_weixin'=>100,
        'task_user_weibo'=>100,
        'task_user_verify'=>300,
        //支付
        'paypal_rate'=>1,
        'paypal_open'=>0,
        'paypal_currency_code'=>'USD'
    );

    public function init(){
        add_action('cmb2_admin_init',array($this,'normal_options_page'));
    }

    /**
     * 获取默认设置项
     *
     * @param string $key 数组键值
     *
     * @return void
     * @author Li Ruchun <lemolee@163.com>
     * @version 1.0.0
     * @since 2018
     */
    public static function get_default_settings($key){
        $arr = array(
            'text_logo'=>get_bloginfo('name'),
            'default_imgs'=>array(B2_THEME_URI.'/Assets/fontend/images/default-img.jpg'),
            'img_logo_white'=>array(),
            'default_video_poster'=>B2_THEME_URI.'/Assets/fontend/images/xg-poster-default.jpg',
            'card_text'=>sprintf(__('请前往%s购买卡密，然后回到此处进行充值','b2'),'<a href="#" target="_balnk">购买卡密</a>'),
            'zz_temp'=>'',
            'register_msg'=>__('欢迎您来到本站！','b2')
        );

        if(isset($arr[$key])){
            return $arr[$key];
        }
    }

    /**
     * 常规设置
     *
     * @return void
     * @author Li Ruchun <lemolee@163.com>
     * @version 1.0.0
     * @since 2018
     */
    public function normal_options_page(){

        $normal = new_cmb2_box( array(
            'id'           => 'b2_normal_main_options_page',
            'object_types' => array( 'options-page' ),
            'option_key'      => 'b2_normal_main',
            'tab_group'    => 'b2_normal_options',
            'parent_slug'     => 'b2_main_options',
            'tab_title'    => __('综合设置','b2'),
            'menu_title'   => __('常规设置','b2'),
        ) );
        
        if(wp_using_ext_object_cache()){
            //开启自带缓存开关
            $normal->add_field(array(
                'name'    => __( '开启主题自带缓存', 'b2' ),
                'desc'    => sprintf(__( '当您使用了redis 或者 memcached 这类数据缓存时，主题将自动对查询和计算量比较大的代码进行结果的缓存%s实际使用过程中建议开启。%s调试主题，修改代码等情况下建议关闭,修改完成即可开启（修改代码以后请在缓存插件中清空一下缓存）', 'b2' ),'<br/>','<br/>'),
                'id'=>'open_cache',
                'type'             => 'select',
                'default'          => self::$default_settings['open_cache'],
                'options'          => array(
                    1 => __( '开启', 'b2' ),
                    0   => __( '关闭', 'b2' ),
                ),
            ));
        }

        //logo设置
        $normal->add_field( array(
            'name'    => __( '图片LOGO（深色）', 'b2' ),
            'desc'    => sprintf(__( '某些顶部背景为白色的情况下使用，建议使用%s格式的图片，以适应高分辨率屏幕。%s如果不设置图片LOGO，网站将显示下面设置的文字LOGO。', 'b2' ),'<code>.svg</code>','<br>'),
            'id'      => 'img_logo',
            'type'    => 'file',
            'options' => array(
                'url' => true, 
            ),
            'text'    => array(
                'add_upload_file_text' => __( '选择LOGO', 'b2' ),
            ),
            'query_args' => array(
                'type' => array(
                    'image/svg+xml',
                    'image/gif',
                    'image/jpeg',
                    'image/png',
                ),
            ),
            'default'=>self::$default_settings['img_logo']
        ));

        //logo设置
        $normal->add_field( array(
            'name'    => __( '图片LOGO（浅色）', 'b2' ),
            'desc'    => sprintf(__( '某些顶部透明的风格下使用，也会视频播放器右上角显示，建议使用%s格式的图片，以适应高分辨率屏幕。%s如果不设置图片LOGO，网站将显示下面设置的文字LOGO。', 'b2' ),'<code>.svg</code>','<br>'),
            'id'      => 'img_logo_white',
            'type'    => 'file',
            'options' => array(
                'url' => true, 
            ),
            'text'    => array(
                'add_upload_file_text' => __( '选择LOGO', 'b2' ),
            ),
            'query_args' => array(
                'type' => array(
                    'image/svg+xml',
                    'image/gif',
                    'image/jpeg',
                    'image/png',
                ),
            ),
            'default'=>self::$default_settings['img_logo_white']
        ));

        //文字LOGO
        $normal->add_field(array(
            'name'    => __( '文字LOGO', 'b2' ),
            'desc'    => __( '默认为您的站点名，您也可以自定义该名称，只在页面顶部显示。', 'b2' ),
            'id'=>'text_logo',
            'type'=>'text',
            'default'=>get_bloginfo('name')
        ));

        //随机缩略图
        $normal->add_field( array(
            'name'    => __( '默认缩略图', 'b2' ),
            'desc'    => __( '可以设置多个默认缩略图，当您的文章没有指定缩略图，并且文章内部没有图片的时候，随机显示这些缩略图。', 'b2' ),
            'id'      => 'default_imgs',
            'type'    => 'file_list',
            'options' => array(
                'url' => true, 
            ),
            'text'    => array(
                'add_upload_file_text' => __( '选择图片', 'b2' ),
            ),
            'query_args' => array(
                'type' => array(
                    'image/svg+xml',
                    'image/gif',
                    'image/jpeg',
                    'image/png',
                ),
            ),
            'default'=>self::$default_settings['default_imgs']
        ));

        //播放器默认缩略图
        $normal->add_field( array(
            'name'    => __( '视频播放器默认缩略图', 'b2' ),
            'desc'    => __( '当您未设置视频封面的时候默认显示此封面。', 'b2' ),
            'id'      => 'default_video_poster',
            'type'    => 'file',
            'options' => array(
                'url' => true, 
            ),
            'text'    => array(
                'add_upload_file_text' => __( '选择图片', 'b2' ),
            ),
            'query_args' => array(
                'type' => array(
                    'image/svg+xml',
                    'image/gif',
                    'image/jpeg',
                    'image/png',
                ),
            ),
            'default'=>self::$default_settings['default_video_poster']
        ));

        //网站连接符
        $normal->add_field(array(
            'name'    => __( '网站货币符号', 'b2' ),
            'desc'    => sprintf(__( '网站涉及到金钱时显示的货币符号，默认%s。', 'b2' ),'<code>￥</code>'),
            'id'=>'money_symbol',
            'type'=>'text',
            'default'=>self::$default_settings['money_symbol']
        ));

        //网站连接符
        $normal->add_field(array(
            'name'    => __( '网站连接符', 'b2' ),
            'desc'    => sprintf(__( '标题与描述之间的分隔符，默认%s。', 'b2' ),'<code>-</code>'),
            'id'=>'separator',
            'type'=>'text',
            'default'=>self::$default_settings['separator']
        ));

        //开启自带缓存开关
        $normal->add_field(array(
            'name'    => __( '分类目录是否去掉category标签', 'b2' ),
            'desc'    => sprintf(__('如果您之前的分类链接里面有%s标签，此时去掉可能影响之前的收录。%s设置完成以后，请重新保存一下固定链接'),'<code>category</code>','<br>'),
            'id'=>'remove_category_tag',
            'type'             => 'select',
            'default'          => 1,
            'options'          => array(
                1 => __( '去掉category', 'b2' ),
                0   => __( '保留category', 'b2' ),
            ),
        ));

        //首页SEO关键词
        $normal->add_field(array(
            'name'=>__('首页SEO关键词','b2'),
            'desc'=>sprintf(__( '建议使用英文的%s隔开，一般3-5个关键词即可，多了会有堆砌嫌疑。', 'b2' ),'<code>,</code>'),
            'id'=>'home_keywords',
            'type'=>'text',
            'default'=>self::$default_settings['home_keywords']
        ));

        //首页SEO描述
        $normal->add_field(array(
            'name'=>__('首页SEO描述','b2'),
            'desc'=>__( '描述你站点的主营业务，一般不超过200个字。', 'b2' ),
            'id'=>'home_description',
            'type'=>'textarea_small',
            'default'=>self::$default_settings['home_description']
        ));

        //头部HTML标签
        $normal->add_field(array(
            'name'=>__('头部HTML标签','b2'),
            'desc'=>sprintf(__( '你可以添加站点的%s等标签，通常情况下，这里是用来放置第三方台验证站点所有权时使用的。', 'b2' ),'<code>'.htmlspecialchars('<meta>、<link>、<style>、<script>').'</code>'),
            'id'=>'header_code',
            'type'=>'textarea_code',
            'options' => array( 'disable_codemirror' => true ),
            'default'=>self::$default_settings['header_code']
        ));

        //底部HTML标签
        $normal->add_field(array(
            'name'=>__('底部HTML标签','b2'),
            'desc'=>sprintf(__( '你可以添加站点的%s等标签，通常情况下，这里是用来加载额外的JS、css文件，或者放置统计代码。', 'b2' ),'<code>'.htmlspecialchars('<style>、<script>').'</code>'),
            'id'=>'footer_code',
            'type'=>'textarea_code',
            'options' => array( 'disable_codemirror' => true ),
            'default'=>self::$default_settings['footer_code']
        ));

        $login = new_cmb2_box(array(
            'id'           => 'b2_normal_login_options_page',
            'tab_title'    => __('登录与注册','b2'), 
            'object_types' => array( 'options-page' ),
            'option_key'      => 'b2_normal_login',
            'parent_slug'     => 'admin.php?page=b2_normal_main',
            'tab_group'    => 'b2_normal_options',
        ));

        //允许注册
        $login->add_field(array(
            'name'    => __( '是否开启注册', 'b2' ),
            'desc'    => __( '建议将wp设置->常规中的<任何人都可以注册>的勾选项去掉，防止机器人注册。', 'b2' ),
            'id'=>'allow_register',
            'type'             => 'select',
            'default'          => self::$default_settings['allow_register'],
            'options'          => array(
                1 => __( '开启', 'b2' ),
                0   => __( '关闭', 'b2' ),
            ),
        ));

        $login->add_field(array(
            'name'    => __( '是否开启cookie兼容模式', 'b2' ),
            'desc'    => __( '如果您使用了一些插件，涉及到用户登录的情况，请开启此项', 'b2' ),
            'id'=>'allow_cookie',
            'type'             => 'select',
            'default'          => self::$default_settings['allow_cookie'],
            'options'          => array(
                1 => __( '开启', 'b2' ),
                0   => __( '关闭', 'b2' ),
            ),
        ));

        $login->add_field(array(
            'name'    => __( '隐私政策网址', 'b2' ),
            'desc'    => __( '如果设置将会显示在登录框底部，请直接填写网址', 'b2' ),
            'id'=>'site_privacy',
            'type'             => 'text',
            'default'          => self::$default_settings['site_privacy'],
        ));

        $login->add_field(array(
            'name'    => __( '用户协议网址', 'b2' ),
            'desc'    => __( '如果设置将会显示在登录框底部，请直接填写网址', 'b2' ),
            'id'=>'site_terms',
            'type'             => 'text',
            'default'          => self::$default_settings['site_terms'],
        ));

        //注册形式
        $login->add_field(array(
            'name'    => __( '请选择身份验证形式', 'b2' ),
            'id'=>'check_type',
            'type'             => 'select',
            'default'          => self::$default_settings['check_type'],
            'options'          => array(
                'tel' => __( '手机验证', 'b2' ),
                'email'   => __( '邮箱验证', 'b2' ),
                'telandemail'   => __( '手机和邮箱均可验证', 'b2' ),
                'text'=>__( '主题自带图形验证', 'b2' ),
                'luo'=>__( 'Luosimao人机验证', 'b2' )
            ),
            'desc'    => sprintf(__( '用于注册，找回密码等操作，四种身份验证形式只能选择其中一种。
            %s如果选择包含邮箱验证，请确认服务器支持邮件发送功能，如果服务器不支持邮件发送，推荐安装%s插件去支持。
            %s如果选择了包含手机验证，请按照下面的提示进行短信设置。
            %s如果选择Luosimao验证，请前往%s申请，然后将%s和%s填入下面设置项中。
            ', 'b2' ),'<br>','<a href="'.admin_url('/plugin-install.php?s=WP+Email+SMTP&tab=search&type=term').'" target="__blank">Easy WP SMTP</a>','<br>','<br>','<a target="_blank" href="https://luosimao.com/service/captcha">Luosimao</a>','<code>site key</code>','<code>secret key</code>'),
        ));

        $login->add_field(array(
            'name'    => __( '社交登陆强制绑定手机、邮箱或用户名', 'b2' ),
            'desc'    => __( '第三方社交注册并未要求用户填写手机号码或邮箱，如果需要强制绑定手机或邮箱，请开启，绑定的是手机、邮箱还是用户名，与上面选择的身份验证形式一致。', 'b2' ),
            'id'=>'build_phone_email',
            'type'             => 'select',
            'options'          => array(
                0 => __( '不要求绑定', 'b2' ),
                1   => __( '强制绑定', 'b2' )
            ),
            'default'          => self::$default_settings['build_phone_email'],
        ));

        $login->add_field(array(
            'name'    => __( '新注册用户消息提示', 'b2' ),
            'desc'    => __( '新用户注册成功以后，会在消息中心有一条新的消息，请在此设置新消息内容', 'b2' ),
            'id'=>'register_msg',
            'type'             => 'textarea_small',
            'default'          => self::get_default_settings('register_msg')
        ));

        //短信服务选择
        $login->add_field(array(
            'before_row'=>'<div id="sms-select" class="cmb-row">',
            'name'    => __( '请选择手机短信服务商', 'b2' ),
            'id'=>'phome_select',
            'type'             => 'select',
            'default'          => self::$default_settings['phome_select'],
            'options'          => array(
                'aliyun' => __( '阿里云', 'b2' ),
                'yunpian'   => __( '云片', 'b2' ),
                'juhe'   => __( '聚合', 'b2' ),
                'zhongzheng'   => __( '中正云', 'b2' ),
                'tencent'   => __( '腾讯云', 'b2' )
            ),
        ));

        //阿里云短信设置
        $login->add_field(array(
            'before_row'=>'<div id="aliyun-sms" class="cmb-row"><h5>'.__('阿里云短信设置','b2').'</h5>',
            'name'    => __( 'AccessKey Id', 'b2' ),
            'desc'    => __( '阿里云控制台->鼠标放到右上角头像上->accessKeys->AccessKey ID。', 'b2' ),
            'id'=>'accesskey_id',
            'type'             => 'text',
            'default'          => self::$default_settings['accesskey_id'],
        ));

        $login->add_field(array(
            'name'    => __( 'Access Key Secret', 'b2' ),
            'desc'    => __( '阿里云控制台->鼠标放到右上角头像上->accessKeys->Access Key Secret。', 'b2' ),
            'id'=>'access_key_secret',
            'attributes' => array(
                'type' => 'password',
            ),
            'type'             => 'text',
            'default'          => self::$default_settings['access_key_secret'],
        ));

        $login->add_field(array(
            'name'    => __( '签名名称', 'b2' ),
            'desc'    => __( '阿里云控制台->短信服务控制台->国内消息->签名管理->签名名称。', 'b2' ),
            'id'=>'sign_name',
            'type'             => 'text',
            'default'          => self::$default_settings['sign_name'],
        ));

        $login->add_field(array(
            'name'    => __( '模板CODE', 'b2' ),
            'desc'    => __( '阿里云控制台->短信服务控制台->国内消息->模板管理->模板CODE。', 'b2' ),
            'id'=>'template_code',
            'type'             => 'text',
            'default'          => self::$default_settings['template_code'],
            'after_row'=>'<p class="red">申请地址：<a href="https://cn.aliyun.com/product/sms" target="__blank">阿里云短信服务</a></p></div>',
        ));

        //云片设置
        $login->add_field(array(
            'before_row'=>'<div id="yunpian-sms" class="cmb-row"><h5>'.__('云片短信设置','b2').'</h5>',
            'name'    => __( 'Apikey', 'b2' ),
            'desc'    => __( '云片管理控制台->账户设置->子账户管理。', 'b2' ),
            'id'=>'apikey',
            'attributes' => array(
                'type' => 'password',
            ),
            'type'             => 'text',
            'default'          => self::$default_settings['apikey'],
        ));

        $login->add_field(array(
            'name'    => __( '模板内容', 'b2' ),
            'desc'    => sprintf(__( '云片管理控制台->国内短信->签名模板报备->已审核的【模板内容】%s
            比如：%s', 'b2' ),'<br>','<code>【'.get_bloginfo('name').'】您的验证码是#code#。如非本人操作，请忽略本短信</code>'),
            'id'=>'yunpian_text',
            'type'             => 'text',
            'default'          => self::$default_settings['yunpian_text'],
            'after_row'=>'<p class="red">申请地址：<a href="https://www.yunpian.com" target="__blank">云片网</a></p></div>',
        ));

        //腾讯云
        $login->add_field(array(
            'before_row'=>'<div id="tencent-sms" class="cmb-row"><h5>'.__('腾讯云短信设置','b2').'</h5>',
            'name'    => __( '短信模板ID', 'b2' ),
            'id'=>'tencent_id',
            'type'             => 'text',
            'default'          => self::$default_settings['tencent_id'],
            'desc'=>__('模板 ID，必须填写已审核通过的模板 ID。模板ID可登录 短信控制台 查看','b2')
        ));

        $login->add_field(array(
            'name'    => __( '短信SdkAppid', 'b2' ),
            'id'=>'tencent_SmsSdkAppid',
            'type'             => 'text',
            'attributes' => array(
                'type' => 'password',
            ),
            'default'          => self::$default_settings['tencent_SmsSdkAppid'],
            'desc'=>__('短信SdkAppid在 短信控制台 添加应用后生成的实际SdkAppid，示例如1400006666。','b2')
        ));

        $login->add_field(array(
            'name'    => __( '短信签名内容', 'b2' ),
            'id'=>'tencent_Sign',
            'type'             => 'text',
            'attributes' => array(
                'type' => 'password',
            ),
            'desc'=>__('短信签名内容，签名信息可登录 短信控制台 查看。','b2'),
            'default'          => self::$default_settings['tencent_Sign'],
            'after_row'=>'<p class="red">申请地址：<a href="https://console.cloud.tencent.com/sms/smslist" target="__blank">腾讯云短信</a></p></div>',
        ));

        //中正云
        $login->add_field(array(
            'before_row'=>'<div id="zhongzheng-sms" class="cmb-row"><h5>'.__('中正云短信设置','b2').'</h5>',
            'name'    => __( '中正云账户', 'b2' ),
            'id'=>'zz_id',
            'type'             => 'text',
            'default'          => self::$default_settings['zz_id'],
        ));

        $login->add_field(array(
            'name'    => __( '中正云密码', 'b2' ),
            'id'=>'zz_password',
            'type'             => 'text',
            'attributes' => array(
                'type' => 'password',
            ),
            'default'          => self::$default_settings['zz_password']
        ));

        $login->add_field(array(
            'name'    => __( '中正云模板', 'b2' ),
            'id'=>'zz_temp',
            'type'             => 'text',
            'attributes' => array(
                'type' => 'text',
            ),
            'default'          => self::get_default_settings('zz_temp'),
            'desc'    => sprintf(__( '比如：%s', 'b2' ),'<code>【'.get_bloginfo('name').'】您的验证码是#code#。如非本人操作，请忽略本短信</code>'),
            'after_row'=>'<p class="red">申请地址：<a href="http://www.winic.org/product/dxyz.asp" target="__blank">中正云</a></p></div>',
        ));

        //聚合设置
        $login->add_field(array(
            'before_row'=>'<div id="juhe-sms" class="cmb-row"><h5>'.__('聚合短信设置','b2').'</h5>',
            'name'    => __( '模板ID', 'b2' ),
            'desc'    => __( '我的聚合->短信API服务->短信模板->模板ID。', 'b2' ),
            'id'=>'tpl_id',
            'type'             => 'text',
            'default'          => self::$default_settings['tpl_id'],
        ));

        $login->add_field(array(
            'name'    => __( 'Appkey', 'b2' ),
            'desc'    => __( '数据中心->我的数据->AppKey。', 'b2' ),
            'id'=>'juhe_key',
            'type'             => 'text',
            'attributes' => array(
                'type' => 'password',
            ),
            'default'          => self::$default_settings['juhe_key'],
            'after_row'=>'<p class="red">申请地址：<a href="https://www.juhe.cn/docs/index/cid/13" target="__blank">聚合网</a></p></div></div>',
        ));
        
        //luosimao验证
        $login->add_field(array(
            'before_row'=>'<div id="luosimao" class="cmb-row"><h5>'.__('luosimao人机验证设置','b2').'</h5>',
            'name'    => __( 'Site key', 'b2' ),
            'desc'    => __( 'luosimao后台->人机验证->操作->设置。', 'b2' ),
            'id'=>'site_key',
            'type'             => 'text',
            'default'          => self::$default_settings['site_key'],
        ));

        $login->add_field(array(
            'name'    => __( 'Api key', 'b2' ),
            'desc'    => __( 'luosimao后台->人机验证->操作->设置。', 'b2' ),
            'id'=>'api_key',
            'type'             => 'text',
            'default'          => self::$default_settings['api_key'],
            'after_row'=>'<p class="red">申请地址：<a href="https://luosimao.com/service/captcha" target="__blank">Luosimao</a></p></div>',
        ));

        //微信扫码登录
        $login->add_field(array(
            'name'    => __( '是否启用微信PC扫码登录', 'b2' ),
            'before_row'=>'<h2>'.__('微信登录设置','b2').'</h2><div class="cmb-row"><p><b>'.__('微信pc端登录设置','b2').'</b></p>',
            'id'=>'wx_pc_open',
            'type'             => 'select',
            'options'          => array(
                1 => __( '开启', 'b2' ),
                0   => __( '关闭', 'b2' )
            ),
            'default'          => self::$default_settings['wx_pc_open'],
        ));

        $login->add_field(array(
            'name'    => __( 'AppID', 'b2' ),
            'id'=>'wx_pc_key',
            'desc'=>__('微信开放平台网站应用的AppID','b2'),
            'type'             => 'text',
            'default'          => self::$default_settings['wx_pc_key'],
        ));

        $login->add_field(array(
            'name'    => __( 'AppSecret', 'b2' ),
            'id'=>'wx_pc_secret',
            'desc'=>__('微信开放平台网站应用的AppSecret','b2'),str_replace(array('http','https'),'',home_url()),
            'type'             => 'text',
            'attributes' => array(
                'type' => 'password',
            ),
            'default'          => self::$default_settings['wx_pc_secret'],
            'after_row'=>'<p class="red">'.sprintf(__('微信扫码登录申请地址：%s；回调地址请填写：%s','b2'),'<a target="_blank" href="https://open.weixin.qq.com/">https://open.weixin.qq.com/</a>',
            str_replace(array('http://','https://'),'',home_url())).'</p></div>'
        ));

        //微信授权登录
        $login->add_field(array(
            'name'    => __( '是否启用微信公众号内授权登录', 'b2' ),
            'before_row'=>'<div class="cmb-row"><p><b>'.__('微信公众号登录设置','b2').'</b></p>',
            'id'=>'wx_gz_open',
            'type'             => 'select',
            'options'          => array(
                1 => __( '开启', 'b2' ),
                0   => __( '关闭', 'b2' )
            ),
            'default'          => self::$default_settings['wx_gz_open'],
        ));

        $login->add_field(array(
            'name'    => __( 'AppID', 'b2' ),
            'id'=>'wx_gz_key',
            'desc'=>__('微信公众平台->基本配置->开发者ID(AppID)','b2'),
            'type'             => 'text',
            'default'          => self::$default_settings['wx_gz_key'],
        ));

        $login->add_field(array(
            'name'    => __( 'AppSecret', 'b2' ),
            'id'=>'wx_gz_secret',
            'attributes' => array(
                'type' => 'password',
            ),
            'desc'=>__('微信公众平台->基本配置->开发者密码','b2'),
            'type'             => 'text',
            'default'          => self::$default_settings['wx_gz_secret'],
            'after_row'=>'<p class="red">'.__('公众号授权登录，请开通微信服务号，微信订阅号无法使用','b2').'<p></div>'
        ));

        //微信授权登录
        $login->add_field(array(
            'name'    => __( '是否开启PC端扫码关注公众号后自动登录？', 'b2' ),
            'before_row'=>'<div class="cmb-row"><p><b>'.__('扫码关注自动登录','b2').'</b></p>',
            'id'=>'wx_mp_login',
            'type'             => 'select',
            'options'          => array(
                1 => __( '开启', 'b2' ),
                0   => __( '关闭', 'b2' )
            ),
            'desc'=>'<p>'.sprintf(__('开启此项，用户点击微信登录会直接显示公众号二维码，用户扫码关注以后自动登录。开启条件：开通了微信服务号并在主题%s常规设置->微信设置%s里面填写了相关设置项。'),'<a target="_blank" href="'.admin_url('/admin.php?page=b2_normal_weixin').'">','</a>').'</p>',
            'default'=> self::$default_settings['wx_gz_open'],
            'after_row'=>'</div>'
        ));

        //QQ登录
        $login->add_field(array(
            'name'    => __( '是否启用QQ授权登录', 'b2' ),
            'before_row'=>'<h2>'.__('QQ登录设置','b2').'</h2><div class="cmb-row">',
            'id'=>'qq_open',
            'type'             => 'select',
            'options'          => array(
                1 => __( '开启', 'b2' ),
                0   => __( '关闭', 'b2' )
            ),
            'default'          => self::$default_settings['qq_open'],
        ));

        $login->add_field(array(
            'name'    => __( 'APP ID', 'b2' ),
            'id'=>'qq_id',
            'type'             => 'text',
            'default'          => self::$default_settings['qq_id'],
        ));

        $login->add_field(array(
            'name'    => __( 'APP Key', 'b2' ),
            'id'=>'qq_secret',
            'attributes' => array(
                'type' => 'password',
            ),
            'type'             => 'text',
            'default'          => self::$default_settings['qq_secret'],
            'after_row'=>'<p class="red">'.sprintf(__('QQ登录申请地址：%s；回调地址请填写：%s','b2'),'<a target="_blank" href="https://connect.qq.com/">https://connect.qq.com/</a>',home_url('/open?type=qq')).'<p></div>'
        ));

        //微博登录
        $login->add_field(array(
            'name'    => __( '是否启用微博授权登录', 'b2' ),
            'before_row'=>'<h2>'.__('微博设置','b2').'</h2><div class="cmb-row">',
            'id'=>'weibo_open',
            'type'             => 'select',
            'options'          => array(
                1 => __( '开启', 'b2' ),
                0   => __( '关闭', 'b2' )
            ),
            'default'          => self::$default_settings['weibo_open'],
        ));

        $login->add_field(array(
            'name'    => __( 'App Key', 'b2' ),
            'id'=>'weibo_id',
            'type'             => 'text',
            'default'          => self::$default_settings['weibo_key'],
        ));

        $login->add_field(array(
            'name'    => __( 'App Secret', 'b2' ),
            'id'=>'weibo_secret',
            'type'             => 'text',
            'attributes' => array(
                'type' => 'password',
            ),
            'default'          => self::$default_settings['weibo_secret'],
            'after_row'=>'<p class="red">'.sprintf(__('微博登录申请地址：%s；回调地址和取消回调地址都填写：%s','b2'),'<a target="_blank" href="http://open.weibo.com/development">http://open.weibo.com/development</a>',home_url('/open?type=weibo')).'<p></div>'
        ));

        //用户设置项
        $user = new_cmb2_box(array(
            'id'           => 'b2_normal_user_options_page',
            'tab_title'    => __('用户设置','b2'), 
            'object_types' => array( 'options-page' ),
            'option_key'      => 'b2_normal_user',
            'parent_slug'     => 'admin.php?page=b2_normal_main',
            'tab_group'    => 'b2_normal_options',
        ));

        $user->add_field(array(
            'name'    => __( '加密用户页面网址', 'b2' ),
            'id'=>'user_id_decode',
            'type'             => 'select',
            'default'          => self::$default_settings['user_id_decode'],
            'desc'    => sprintf(__( '加密前：%s%s加密后：%s%s设置完成以后请保存一下固定链接，前端用户需要重新登录', 'b2' ),'<code>'.home_url().'/people/<span class="red">123</span></code>','<br>','<code>'.home_url().'/people/<span class="red">pXyQNJVVV</span></code>','<br><span class="red">','</span>'),
            'options'          => array(
                1 => __( '加密', 'b2' ),
                0 => __( '不加密', 'b2' ),
            ),
        ));

        $user->add_field(array(
            'name'    => __( '重写用户页面规则', 'b2' ),
            'desc'    => sprintf(__( '如果需要用户页面是%s，则在此处填写%s%s设置完成以后请保存一下固定链接，前端用户需要重新登录', 'b2' ),'<code>'.home_url().'/<span class="red">people</span>/123</code>','<code>people</code>','<br><span class="red">','</span>'),
            'id'=>'user_slug',
            'type'             => 'text',
            'default'          => self::$default_settings['user_slug'],
        ));

        // $user->add_field(array(
        //     'name'    => __( '是否使用默认字母头像', 'b2' ),
        //     'id'=>'user_avatar_open',
        //     'type'             => 'select',
        //     'default'          => self::$default_settings['user_avatar_open'],
        //     'options'          => array(
        //         1 => __( '使用', 'b2' ),
        //         0 => __( '关闭', 'b2' ),
        //     ),
        // ));

        // $user->add_field(array(
        //     'name'    => __( '默认字母头像使用第一个字符还是最后一个字符', 'b2' ),
        //     'id'=>'user_avatar_letter',
        //     'type'             => 'select',
        //     'default'          => self::$default_settings['user_avatar_letter'],
        //     'options'          => array(
        //         1 => __( '第一个字符', 'b2' ),
        //         0 => __( '最后一个字符', 'b2' ),
        //     ),
        // ));

        //用户等级设置
        $user_lv_group = $user->add_field( array(
            'before_row'=>'<span class="red">'.__('请不要随意改变下面等级的排序，也不要随意在中间插入新的等级，否则可能造成老用户的等级失效。').'</span>',
            'id'          => 'user_lv_group',
            'type'        => 'group',
            'description' => __( '普通用户等级设置（LV0等级需要的积分请设置为0，否则新用户没有等级提示）', 'b2' ),
            'options'     => array(
                'group_title'       => '<span class="lv-name"></span><b>（lv{#}）</b>', 
                'add_button'        => __( '添加新等级', 'b2' ),
                'remove_button'     => __( '删除等级', 'b2' ),
                'sortable'          => true,
                'closed'         => true, 
                'remove_confirm' => __( '确定要删除这个等级吗？', 'b2' ), 
            )
        ));

        $user->add_group_field( $user_lv_group, array(
            'name' => __('该等级的对外名称','b2'),
            'id'   => 'name',
            'type' => 'text',
            'desc'=>sprintf(__('比如 %s 等等','b2'),'<code>学前班</code><code>周会员</code>')
        ) );

        $user->add_group_field( $user_lv_group, array(
            'name' => __('到达此等级需要的积分','b2'),
            'id'   => 'credit',
            'type' => 'text',
            'desc'=>sprintf(__('比如 %s 积分，用户会达到此积分便会升级为此等级','b2'),'<code>1000</code>')
        ) );

        $user->add_group_field( $user_lv_group, array(
            'name' => __('该等级的权限','b2'),
            'id'      => 'user_role',
            'type'    => 'multicheck_inline',
            'options' => b2_roles_arg()
        ) );

        //vip用户等级设置
        $user_vip_group = $user->add_field( array(
            'before_row'=>'<span class="red">'.__('请不要随意改变下面等级的排序，也不要随意在中间插入新的等级，否则可能造成老用户的等级失效。').'</span>',
            'id'          => 'user_vip_group',
            'type'        => 'group',
            'description' => __( '付费用户等级设置（设置好以后不要随意变动，如果这里删除等级，对应的会员也会删除等级）', 'b2' ),
            'options'     => array(
                'group_title'       => '<span class="lv-name"></span><b>（vip{#}）</b>', 
                'add_button'        => __( '添加新等级', 'b2' ),
                'remove_button'     => __( '删除等级', 'b2' ),
                'sortable'          => true,
                'closed'         => true, 
                'remove_confirm' => __( '确定要删除这个等级吗？', 'b2' ), 
            ),
        ));

        $user->add_group_field( $user_vip_group, array(
            'name' => __('该等级的对外名称','b2'),
            'id'   => 'name',
            'type' => 'text',
            'desc'=>sprintf(__('比如 %s 等等','b2'),'<code>超级会员</code><code>白金会员</code>')
        ) );

        $user->add_group_field( $user_vip_group, array(
            'name' => __('该等级的对外显示的颜色','b2'),
            'id'   => 'color',
            'type' => 'colorpicker',
        ) );

        $user->add_group_field( $user_vip_group, array(
            'name' => __('购买此等级需要支付的费用','b2'),
            'id'   => 'price',
            'type' => 'text_money',
            'before_field' => B2_MONEY_SYMBOL,
            'desc'=>sprintf(__('比如 %s 元，用户支付了这些费用，便会成为此等级用户，如果设置为0将不允许用户购买','b2'),'<code>100</code>')
        ) );

        $user->add_group_field( $user_vip_group, array(
            'name' => __('该等级的有效期','b2'),
            'id'   => 'time',
            'type' => 'text',
            'desc'=>sprintf(__('此处为用户从购买会员到会员过期的时间，比如 %s 天，请直接填写天数的数字，永久有效请填0。','b2'),'<code>30</code>')
        ) );

        $user->add_group_field( $user_vip_group, array(
            'name' => __('是否允许查看所有隐藏内容','b2'),
            'id'   => 'allow_read',
            'type'             => 'select',
            'default'          => 0,
            'options'          => array(
                1 => __( '允许', 'b2' ),
                0 => __( '禁止', 'b2' ),
            ),
            'desc'=>__('对文章中隐藏代码包裹起来的内容有效','b2')
        ) );

        $user->add_group_field( $user_vip_group, array(
            'name' => __('是否允许下载所有资源','b2'),
            'id'   => 'allow_download',
            'type'             => 'select',
            'default'          => 0,
            'options'          => array(
                1 => __( '允许', 'b2' ),
                0 => __( '禁止', 'b2' ),
            ),
            'desc'=>__('将会允许此等级用户免费下载所有文章中设置的下载资源','b2')
        ));

        $user->add_group_field( $user_vip_group, array(
            'name' => __('允许每天下载的次数','b2'),
            'id'   => 'allow_download_count',
            'type'             => 'text',
            'default'          => 20,
            'desc'=>__('如果允许此等级用户免费下载所有资源，可能会出现有人恶意采集的问题，在此设置允许每天下载的次数，可以有效防止。如果当天下载次数达到最大，将按照下载中设置的付费金额进行收费下载。','b2')
        ));

        $user->add_group_field( $user_vip_group, array(
            'name' => __('是否允许查看所有付费视频','b2'),
            'id'   => 'allow_videos',
            'type'             => 'select',
            'default'          => 0,
            'options'          => array(
                1 => __( '允许', 'b2' ),
                0 => __( '禁止', 'b2' ),
            ),
            'desc'=>__('将会允许此等级用户免费查看所有付费视频内容','b2')
        ));

        $user->add_group_field( $user_vip_group, array(
            'name' => __('初始人数','b2'),
            'id'   => 'count',
            'type'             => 'text',
            'default'          => 300,
            'desc'=>__('新站vip购买页面显示VIP数量太少，这里可以设置一个初始数量，让数据看上去漂亮一些','b2')
        ));

        $user->add_group_field( $user_vip_group, array(
            'name' => __('该等级的权限','b2'),
            'id'      => 'user_role',
            'type'    => 'multicheck_inline',
            'options' => b2_roles_arg()
        ) );

        self::write_settings();
        self::pay_settings();
        self::gold_settings();
        self::task_settings();
        self::weixin_settings();
        self::weixin_menu();
    }

    public static function write_settings(){

        $lvs = User::get_user_roles();

        $setting_lvs = array();
        foreach($lvs as $k => $v){
            $setting_lvs[$k] = $v['name'];
        }

        if(b2_get_option('verify_main','verify_allow')){
            $setting_lvs['verify'] = __('认证用户','b2');
        }

        $write = new_cmb2_box(array(
            'id'           => 'b2_normal_write_options_page',
            'tab_title'    => __('投稿及媒体权限','b2'), 
            'object_types' => array( 'options-page' ),
            'option_key'      => 'b2_normal_write',
            'parent_slug'     => 'admin.php?page=b2_normal_main',
            'tab_group'    => 'b2_normal_options',
        ));

        //是否允许用户投稿
        $write->add_field(array(
            'name'    => __( '是否允许用户投稿', 'b2' ),
            'id'      => 'write_allow',
            'type'    => 'radio_inline',
            'options' => array(
                1 => __( '允许投稿', 'b2' ),
                0   => __( '禁止投稿', 'b2' ),
            ),
            'default' => self::$default_settings['write_allow'],
        ));

        //默认投稿的分类ID
        $write->add_field(array(
            'name'    => __( '限制投稿', 'b2' ),
            'id'      => 'write_can_post',
            'type'    => 'text',
            'default'=>3,
            'desc'=>__('普通用户多少篇投稿未审核时不允许再次投稿，管理员，作者不受此数量限制.（此项设置可以防止垃圾投稿）','b2')
        ));

        //允许投稿的分类
        $write->add_field(array(
            'name' => __('允许投稿的分类','b2'),
            'id'   => 'write_cats',
            'type' => 'taxonomy_multicheck_hierarchical',
            'taxonomy'=>'category',
            // Optional :
            'text'           => array(
                'no_terms_text' => sprintf(__('没有分类，请前往%s添加','b2'),'<a target="_blank" href="'.admin_url('/edit-tags.php?taxonomy=category').'">分类设置</a>')
            ),
            'remove_default' => 'true', // Removes the default metabox provided by WP core.
            // Optionally override the args sent to the WordPress get_terms function.
            'query_args' => array(
                'orderby' => 'count',
                'hide_empty' => false,
            ),
            'select_all_button' => true,
            'desc'=>__('请确保您的分类别名不是中文，否则无法选中，不选择将不显示分类设置的选项','b2'),
        ));

        //默认投稿的分类ID
        $write->add_field(array(
            'name'    => __( '默认投稿的分类ID', 'b2' ),
            'id'      => 'write_cats_default',
            'type'    => 'text',
            'desc'=>__('请直接填写分类ID，不设置则默认投入ID为1的分类中','b2')
        ));

        //允许投稿的专题
        $write->add_field(array(
            'name' => __('允许投稿的专题','b2'),
            'id'   => 'write_callections',
            'type' => 'taxonomy_multicheck_hierarchical',
            'taxonomy'=>'collection',
            // Optional :
            'text'           => array(
                'no_terms_text' => sprintf(__('没有专题，请前往%s添加','b2'),'<a target="_blank" href="'.admin_url('/edit-tags.php?taxonomy=collection').'">专题设置</a>')
            ),
            'remove_default' => 'true', // Removes the default metabox provided by WP core.
            // Optionally override the args sent to the WordPress get_terms function.
            'query_args' => array(
                'orderby' => 'count',
                'hide_empty' => false,
            ),
            'select_all_button' => true,
            'desc'=>__('请确保您的专题别名不是中文，否则无法选中，不选择将不显示专题设置的选项','b2'),
        ));

        //默认投稿的专题ID
        $write->add_field(array(
            'name'    => __( '默认投稿的专题ID', 'b2' ),
            'id'      => 'write_callections_default',
            'type'    => 'text',
            'desc'=>__('请直接填写专题ID，不设置则默认不设置专题','b2')
        ));

        $write->add_field(array(
            'name' => __('哪些等级投稿时直接发布，不用审核','b2'),
            'id'   => 'write_post_role',
            'type' => 'multicheck_inline',
            'options'=>$setting_lvs,
            'desc'=> __('选择之后，这些等级的用户发布文章之后不用审核，并且可以无限制修改自己的文章','b2')
        ));

        $write->add_field(array(
            'name'=>__('投稿自定义字段设置','b2'),
            'id'=>'write_custom_code',
            'type'=>'select',
            'options'=>array(
                0=>__('不使用','b2'),
                1=>__('使用','b2')
            ),
            'default'=>0,
            'desc'=>__('如果禁止投稿用户设置权限，将不会显示隐藏内容按钮','b2'),
        ));

        $custom_code = $write->add_field( array(
            'id'          => 'write_custom_group',
            'type'        => 'group',
            'options'     => array(
                'group_title'       => __( '自定义字段{#}', 'b2' ), 
                'add_button'        => __( '添加新的自定义字段', 'b2' ),
                'remove_button'     => __( '删除自定义字段', 'b2' ),
                'sortable'          => true,
                'closed'         => true, 
                'remove_confirm' => __( '确定要删除这个自定义字段吗？', 'b2' ), 
            )
        ));

        $write->add_group_field( $custom_code, array(
            'name' => __('自定义字段名称','b2'),
            'id'   => 'name',
            'type' => 'text',
            'desc'=>sprintf(__('提示用户要设置的是什么，比如：%s水果%s','b2'),'<code>','</code>')
        ) );

        $write->add_group_field( $custom_code, array(
            'name' => __('自定义字段key','b2'),
            'id'   => 'key',
            'type' => 'text',
            'desc'=>sprintf(__('请使用英文，比如%sfruit_name%s（水果名称）','b2'),'<code>','</code>')
        ) );

        $write->add_group_field( $custom_code, array(
            'name' => __('描述','b2'),
            'id'   => 'desc',
            'type' => 'textarea_small',
            'desc'=>sprintf(__('向用户说明这个选项如何使用，比如：%s请选择您喜欢的水果%s','b2'),'<code>','</code>')
        ) );

        $write->add_group_field( $custom_code, array(
            'name' => __('表单形式','b2'),
            'id'   => 'type',
            'type' => 'select',
            'options'=>array(
                'text'=>__('单行文本','b2'),
                'textarea'=>__('多行文本','b2'),
                'radio'=>__('单选','b2'),
                'checkbox'=>__('多选','b2')
            )
        ) );

        $write->add_group_field( $custom_code, array(
            'name' => __('待选值','b2'),
            'id'   => 'value',
            'type' => 'textarea',
            'desc'=>sprintf(__('如果表单形式选择单选，或者多选，请填写待选值，否则请留空。每组值占一行，推荐使用%sapple=苹果%s这种形式，%sapple%s是存入数据库里的值，%s苹果%s是显示出来给用户看的（英文的值方便查找与管理）。比如：%sapple=苹果%sorange=橘子%s'),'<code>','</code>','<code>','</code>','<code>','</code>','<br><code>','</code><br><code>','</code>')
        ) );

        $write->add_field(array(
            'before_row'=>'<h2>'.__('媒体权限','b2').'</h2><p>'.__('媒体权限全站生效','b2').'</p>',
            'name' => __('哪些等级允许上传图片？','b2'),
            'id'   => 'write_image_role',
            'type' => 'multicheck_inline',
            'options'=>$setting_lvs,
            'desc'=> __('这里设置以后，全站生效，选择之后，只有这些等级允许上传视频','b2')
        ));

        $write->add_field(array(
            'name'    => __( '允许上传图片的最大体积', 'b2' ),
            'id'      => 'write_image_size',
            'type'    => 'text',
            'default'=>self::$default_settings['write_image_size'],
            'desc'=>__('这里设置以后，全站生效，全站的图片体积都不允许超过此范围，单位是M，请直接填写数字','b2')
        ));

        $write->add_field(array(
            'name' => __('哪些等级允许上传视频？','b2'),
            'id'   => 'write_video_role',
            'type' => 'multicheck_inline',
            'options'=>$setting_lvs,
            'desc'=> __('这里设置以后，全站生效，选择之后，只有这些等级允许上传视频','b2')
        ));

        $write->add_field(array(
            'name'    => __( '允许上传视频的最大体积', 'b2' ),
            'id'      => 'write_video_size',
            'type'    => 'text',
            'default'=>self::$default_settings['write_video_size'],
            'desc'=>__('这里设置以后，全站生效，全站上传的视频体积都不允许超过此范围，单位是M，请直接填写数字','b2')
        ));

        $write->add_field(array(
            'name' => __('哪些等级允许上传文件？','b2'),
            'id'   => 'write_file_role',
            'type' => 'multicheck_inline',
            'options'=>$setting_lvs,
            'desc'=> __('这里设置以后，全站生效，选择之后，只有这些等级允许上传文件','b2')
        ));

        $write->add_field(array(
            'name'    => __( '允许上传文件的最大体积', 'b2' ),
            'id'      => 'write_file_size',
            'type'    => 'text',
            'default'=>self::$default_settings['write_file_size'],
            'desc'=>__('这里设置以后，全站生效，全站上传的文件体积都不允许超过此范围，单位是M，请直接填写数字','b2')
        ));
    } 

    public static function pay_settings(){
        $pay = new_cmb2_box(array(
            'id'           => 'b2_normal_pay_options_page',
            'tab_title'    => __('支付设置','b2'), 
            'object_types' => array( 'options-page' ),
            'option_key'      => 'b2_normal_pay',
            'parent_slug'     => 'admin.php?page=b2_normal_main',
            'tab_group'    => 'b2_normal_options',
        ));

        //选择支付宝支付方式
        $pay->add_field(array(
            'name'    => __( '是否开启paypal', 'b2' ),
            'id'      => 'paypal_open',
            'type'    => 'select',
            'options' => array(
                '0' => __( '关闭', 'b2' ),
                '1'=>__('开启','b2')
            ),
            'default' => '0',
            'before_row'=>'<p class="red">'.__('第三方支付不能保证100%安全，我们只对接口做兼容，其他请自行负责，有条件的话推荐使用官方接口。','b2').'</p>'
        ));

        //选择支付宝支付方式
        $pay->add_field(array(
            'name'    => __( '支付宝', 'b2' ),
            'id'      => 'alipay',
            'type'    => 'select',
            'options' => array(
                '0' => __( '关闭', 'b2' ),
                'alipay_normal'  => __( '支付宝官方', 'b2' ),
                'xunhu'  => __( '迅虎支付(h5支付)', 'b2' ),
                'alipay_hupijiao'  => __( '虎皮椒支付', 'b2' ),
                'mapay'=>__( '码支付', 'b2' ),
                'xorpay'=>__('xorpay支付'),
                'yipay'=>__('易支付','b2')
                //'payjs'=>__('payjs支付'),
            ),
            'default' => '0',
        ));

        //微信支付方式
        $pay->add_field(array(
            'name'    => __( '微信', 'b2' ),
            'id'      => 'wecatpay',
            'type'    => 'select',
            'options' => array(
                '0' => __( '关闭', 'b2' ),
                'wecatpay_normal'  => __( '微信官方', 'b2' ),
                'xunhu'  => __( '迅虎支付(h5支付)', 'b2' ),
                'wecatpay_hupijiao'  => __( '虎皮椒支付', 'b2' ),
                'mapay'=>__( '码支付', 'b2' ),
                'xorpay'=>__('xorpay支付'),
                'payjs'=>__('payjs支付'),
                'yipay'=>__('易支付','b2')
            ),
            'default' => '0'
        ));

        //支付宝官方
        $pay->add_field(array(
            'name'    => __( '支付方式', 'b2' ),
            'id'      => 'alipay_type',
            'type'    => 'select',
            'options' => array(
                'normal' => __( '常规方式', 'b2' ),
                'scan'  => __( '当面付', 'b2' ),
            ),
            'desc'=>__('如果你是支付宝企业账户，推荐使用常规方式，兼容性最好。如果您是个人用户只能选择当面付，当面付支持手机和移动端支付','b2'),
            'default' => 'normal',
            'before_row'=>'<div id="alipay_normal" class="cmb-row"><h2>'.__('支付宝官方支付设置','b2').'</h2>',
        ));

        $pay->add_field(array(
            'name'    => __( 'APPID', 'b2' ),
            'id'      => 'alipay_appid',
            'type'    => 'text',
            'desc'=>__('打开链接： https://open.alipay.com 账户中心->密钥管理->开放平台密钥，填写您支付的应用的APPID','b2')
        ));

        $pay->add_field(array(
            'name'    => __( '应用私钥', 'b2' ),
            'id'      => 'alipay_private_key',
            'type'    => 'textarea',
            'desc'=>__('本主题使用的是 RSA2 算法生成的私钥。请使用 RSA2 算法来生成。','b2')
        ));

        $pay->add_field(array(
            'name'    => __( '支付宝公钥', 'b2' ),
            'id'      => 'alipay_public_key',
            'type'    => 'textarea',
            'after_row'=>'</div>',
            'desc'=>__('请在 账户中心->密钥管理->开放平台密钥，找到添加了支付功能的应用，根据你的加密类型，查看支付宝公钥。','b2')
        ));

        //选择支付宝支付方式
        $pay->add_field(array(
            'name'    => __( 'Paypal收款Email', 'b2' ),
            'id'      => 'paypal_email',
            'type'    => 'input',
            'desc'=>__('您的收款账户，通常为email','b2'),
            'before_row'=>'<div id="paypal_normal" class="cmb-row"><h2>'.__('Paypal官方支付设置','b2').'</h2>',
        ));

        $pay->add_field(array(
            'name'    => __( '结算货币', 'b2' ),
            'id'      => 'paypal_currency_code',
            'type'    => 'select',
            'options'=>array(
                'AUD'=>'Australian dollar (AUD)',
                'BRL'=>'Brazilian real (BRL)',
                'CAD'=>'Canadian dollar (CAD)',
                'CZK'=>'Czech koruna (CZK)',
                'DKK'=>'Danish krone (DKK)',
                'EUR'=>'Euro (EUR)',
                'HKD'=>'Hong Kong dollar (HKD)',
                'HUF'=>'Hungarian forint (HUF)',
                'INR'=>'Indian rupee (INR)',
                'ILS'=>'Israeli new shekel (ILS)',
                'JPY'=>'Japanese yen (JPY)',
                'MYR'=>'Malaysian ringgit (MYR)',
                'MXN'=>'Mexican peso (MXN)',
                'TWD'=>'New Taiwan dollar (TWD)',
                'NZD'=>'New Zealand dollar (NZD)',
                'NOK'=>'Norwegian krone (NOK)',
                'PHP'=>'Philippine peso (PHP)',
                'PLN'=>'Polish złoty (PLN)',
                'GBP'=>'Pound sterling (GBP)',
                'RUB'=>'Russian ruble (RUB)',
                'SGD'=>'Singapore dollar (SGD)',
                'SEK'=>'Swedish krona (SEK)',
                'CHF'=>'Swiss franc (CHF)',
                'THB'=>'Thai baht (THB)',
                'USD'=>'United States dollar (USD)'
            ),
            'desc'=>__('请选择结算货币','b2')
        ));

        $pay->add_field(array(
            'name'    => __( '汇率', 'b2' ),
            'id'      => 'paypal_rate',
            'type'    => 'text',
            'desc'=>__('转换成paypal支付货币的汇率，比如1人民币兑换0.1430美元，这里就填0.1430','b2'),
            'after'=>'</div>'
        ));

        //迅虎支付

        $pay->add_field(array(
            'name'    => __( 'MCHID', 'b2' ),
            'id'      => 'xunhu_appid',
            'type'    => 'text',
            'desc'=>__('进入迅虎支付平台，查看商户ID','b2'),
            'before_row'=>'<div id="xunhu" class="cmb-row"><h2>'.__('迅虎支付设置（支持支付宝和微信）','b2').'</h2>',
        ));

        $pay->add_field(array(
            'name'    => __( 'PRIVATE KEY', 'b2' ),
            'id'      => 'xunhu_appsecret',
            'type'    => 'text',
            'desc'=>__('进入迅虎支付平台，查看应用PRIVATE KEY','b2'),
        ));

        $pay->add_field(array(
            'name'    => __( '支付网关', 'b2' ),
            'id'      => 'xunhu_gateway',
            'type'    => 'text',
            'default'=>'https://admin.xunhuweb.com',
            'desc'=>__('留空则使用默认网关，如无特别升级，请留空,申请地址：<a href="https://pay.xunhuweb.com" target="_blank">https://pay.xunhuweb.com</a>','b2'),
            'after_row'=>'</div>'
        ));

        //虎皮椒支付宝
        $pay->add_field(array(
            'name'    => __( 'appid', 'b2' ),
            'id'      => 'alipay_hupijiao_appid',
            'type'    => 'text',
            'before_row'=>'<div id="alipay_hupijiao" class="cmb-row"><h2>'.__('虎皮椒支付宝设置（支持支付宝支付）','b2').'</h2>',
        ));

        $pay->add_field(array(
            'name'    => __( 'appsecret', 'b2' ),
            'id'      => 'alipay_hupijiao_appsecret',
            'type'    => 'text',
        ));

        $pay->add_field(array(
            'name'    => __( '支付网关', 'b2' ),
            'id'      => 'alipay_hupijiao_gateway',
            'type'    => 'text',
            'default'=>'https://api.xunhupay.com/payment/do.html',
            'desc'=>__('留空则使用默认网关，如无特别升级，请留空','b2'),
            'after_row'=>'</div>'
        ));

        //虎皮椒微信
        $pay->add_field(array(
            'name'    => __( 'appid', 'b2' ),
            'id'      => 'wecatpay_hupijiao_appid',
            'type'    => 'text',
            'before_row'=>'<div id="wecatpay_hupijiao" class="cmb-row"><h2>'.__('虎皮椒微信支付设置（支持微信支付）','b2').'</h2>',
        ));

        $pay->add_field(array(
            'name'    => __( 'appsecret', 'b2' ),
            'id'      => 'wecatpay_hupijiao_appsecret',
            'type'    => 'text',
        ));

        $pay->add_field(array(
            'name'    => __( '支付网关', 'b2' ),
            'id'      => 'wecatpay_hupijiao_gateway',
            'type'    => 'text',
            'default'=>'https://api.xunhupay.com/payment/do.html',
            'desc'=>__('留空则使用默认网关，如无特别升级，请留空','b2'),
            'after_row'=>'</div>'
        ));

        //payjs
        $pay->add_field(array(
            'name'    => __( '商户号', 'b2' ),
            'id'      => 'payjs_mchid',
            'type'    => 'text',
            'desc'=>__('请登录payjs.cn会员中心查看','b2'),
            'before_row'=>'<div id="payjs" class="cmb-row"><h2>'.__('payjs支付设置（支持支付宝和微信）','b2').'</h2>',
        ));

        $pay->add_field(array(
            'name'    => __( '密钥', 'b2' ),
            'id'      => 'payjs_key',
            'type'    => 'text',
            'desc'=>__('请登录payjs.cn会员中心查看。','b2'),
            'after_row'=>'</div>'
        ));

        //易支付
        $pay->add_field(array(
            'name'    => __( '接口网址', 'b2' ),
            'id'      => 'yipay_gateway',
            'type'    => 'text',
            'desc'=>__('您的易支付接口网址','b2'),
            'before_row'=>'<div id="yipay" class="cmb-row"><h2>'.__('易支付（支持支付宝和微信）','b2').'</h2>',
        ));

        $pay->add_field(array(
            'name'    => __( '商户ID', 'b2' ),
            'id'      => 'yipay_id',
            'type'    => 'text',
            'desc'=>__('商户ID','b2'),
        ));

        $pay->add_field(array(
            'name'    => __( '商户KEY', 'b2' ),
            'id'      => 'yipay_key',
            'type'    => 'text',
            'desc'=>__('商户KEY','b2'),
            'after_row'=>'</div>'
        ));

        //码支付
        $pay->add_field(array(
            'name'    => __( '码支付付款方式', 'b2' ),
            'id'      => 'mapay_type',
            'type'    => 'select',
            'options' => array(
                1 => __( '跳转页面支付', 'b2' ),
                4  => __( '二维码支付', 'b2' )
            ),
            'default'=>1,
            'desc'=>__('二维码支付需要您在码支付后台上传您对应的金额二维码，如果没有上传可能会无法回调，如果您之不知道怎么使用，建议直接用跳转模式','b2'),
            'before_row'=>'<div id="mapay" class="cmb-row"><h2>'.__('码支付设置（支持支付宝和微信）','b2').'</h2>',
        ));

        $pay->add_field(array(
            'name'    => __( '码支付ID', 'b2' ),
            'id'      => 'mapay_id',
            'type'    => 'text',
            'desc'=>__('码支付后台->系统设置->码支付ID','b2'),
        ));

        $pay->add_field(array(
            'name'    => __( '通讯密钥', 'b2' ),
            'id'      => 'mapay_key',
            'type'    => 'text',
            'desc'=>__('码支付后台->系统设置->通讯密钥','b2'),
            'after_row'=>'</div>'
        ));

        //xorpay支付
        $pay->add_field(array(
            'name'    => __( 'aid', 'b2' ),
            'id'      => 'xorpay_aid',
            'type'    => 'text',
            'desc'=>__('xorpay 后台，应用配置中查看','b2'),
            'before_row'=>'<div id="xorpay" class="cmb-row"><h2>'.__('xorpay支付设置（支持支付宝和微信）','b2').'</h2><p>申请地址:<a href="https://xorpay.com?r=lemolee" target="_blank">xorpay</a></p>'
        ));

        $pay->add_field(array(
            'name'    => __( 'app appsecret', 'b2' ),
            'id'      => 'xorpay_secret',
            'type'    => 'text',
            'desc'=>__('xorpay 后台，应用配置中查看','b2'),
            'after_row'=>'</div>'
        ));

        //微信官方支付
        $pay->add_field(array(
            'name'    => __( 'APPID', 'b2' ),
            'id'      => 'wecatpay_appid',
            'type'    => 'text',
            'desc'=>__('进入微信公众平台（服务号）->左侧菜单最下面->基本配置->开发者ID(AppID)','b2'),
            'before_row'=>'<div id="wecatpay_normal" class="cmb-row"><h2>'.__('微信官方支付设置','b2').'</h2>
            <p>使用条件：</p><p>1、需要开通微信公众号和微信商户；</p><p>2、并且微信商户->产品中心 开通了 Native 支付，H5支付（手机浏览器使用）</p><p>3、并且微信商户->产品中心->开发配置->填写JSAPI支付目录和H5支付域名</p><p>4、并且微信服务号->基本配置里面设置一下IP白名单</p>',
        ));

        $pay->add_field(array(
            'name'    => __( '微信支付商户号', 'b2' ),
            'id'      => 'wecatpay_mch_id',
            'type'    => 'text',
            'desc'=>__('进入微信商户平台->商户信息->基本信息->商户号，','b2'),
        ));

        $pay->add_field(array(
            'name'    => __( '商户支付密钥', 'b2' ),
            'id'      => 'wecatpay_secret',
            'type'    => 'text',
            'desc'=>__('进入微信商户平台->API安全->API密钥','b2'),
            'after_row'=>'</div>'
        ));
    }

    public static function gold_settings(){
        $gold = new_cmb2_box(array(
            'id'           => 'b2_gold_options_page',
            'tab_title'    => __('财富设置','b2'), 
            'object_types' => array( 'options-page' ),
            'option_key'      => 'b2_normal_gold',
            'parent_slug'     => 'admin.php?page=b2_normal_main',
            'tab_group'    => 'b2_normal_options',
        ));

        $gold->add_field(array(
            'name' => __('是否允许提现','b2'),
            'id'      => 'gold_tx',
            'type'    => 'select',
            'options' => array(
                0=>__( '禁止提现', 'b2' ),
                1=>__( '允许提现', 'b2' )
            ),
            'before_row'=>'<h2>'.__('提现设置','b2').'</h2>'
        ) );

        $gold->add_field(array(
            'name' => __('余额超过多少允许提现','b2'),
            'id'   => 'gold_money',
            'default'=> 50,
            'type' => 'text_money',
            'before_field' => B2_MONEY_SYMBOL,
            'desc'=>__('用户余额大于或者等于这个金额方可允许提现','b2')
        ));

        $gold->add_field(array(
            'name' => __('网站提成比例','b2'),
            'id'   => 'gold_tc',
            'default'=> '0.05',
            'type' => 'text',
            'desc'=>__('默认 0.05 （5%），如果网站不抽成，请设置为0。','b2')
        ));
        
        $gold->add_field(array(
            'name' => __('是否允许卡密充值？','b2'),
            'id'      => 'card_allow',
            'type'    => 'select',
            'default'=>self::$default_settings['card_allow'],
            'options' => array(
                0=>__( '禁止使用', 'b2' ),
                1=>__( '允许使用', 'b2' )
            ),
            'before_row'=>'<h2>'.__('卡密充值设置','b2').'</h2>'
        ) );

        $gold->add_field(array(
            'name' => __('卡密充值弹窗提示信息','b2'),
            'id'      => 'card_text',
            'type'    => 'textarea',
            'desc'=>__('通常用来提示用户去哪购买的文字','b2'),
            'default'=>self::get_default_settings('card_text')
        ) );

        $gold->add_field(array(
            'name' => __('1元人民币兑换多少积分','b2'),
            'id'      => 'credit_dh',
            'type'    => 'text',
            'default'=>self::$default_settings['credit_dh'],
            'desc'=>__('默认1元兑换38积分','b2'),
            'before_row'=>'<h2>'.__('积分兑换','b2').'</h2><p>为了避免用户故意刷积分的问题存在，暂时只限制允许购买积分，不允许积分兑换余额</p>'
        ) );

        $gold->add_field(array(
            'name' => __('多少元起兑','b2'),
            'id'      => 'credit_qc',
            'type'    => 'text',
            'default'=>self::$default_settings['credit_qc'],
            'desc'=>__('默认10元起兑','b2'),
        ) );

        $gold->add_field(array(
            'name' => __('新用户注册','b2'),
            'id'      => 'credit_login',
            'type'    => 'text',
            'default'=>self::$default_settings['credit_login'],
            'desc'=>__('奖励对象：注册者。默认260分。首次注册时奖励。','b2'),
            'before_row'=>'<h2>'.__('积分奖励','b2').'</h2><p>'.__('如果不允许奖励积分，请设置为0').'</p>'
        ) );

        $gold->add_field(array(
            'name' => __('发表文章','b2'),
            'id'      => 'credit_post',
            'type'    => 'text',
            'default'=>self::$default_settings['credit_post'],
            'desc'=>__('奖励对象：文章作者。默认200分。草稿状态不算，只有审核通过才算','b2'),
        ) );

        $gold->add_field(array(
            'name' => __('评论奖励','b2'),
            'id'      => 'credit_comment',
            'type'    => 'text',
            'default'=>self::$default_settings['credit_comment'],
            'desc'=>__('奖励对象：发表评论者。默认20分。（此评论积分设置包含文章、冒泡、研究所的评论）','b2'),
        ) );

        $gold->add_field(array(
            'name' => __('评论被点赞','b2'),
            'id'      => 'credit_comment_up',
            'type'    => 'text',
            'default'=>self::$default_settings['credit_comment_up'],
            'desc'=>__('奖励对象：评论作者。取消点赞评论作者会扣除相应的积分，默认5分。（此评论积分设置包含文章、冒泡、研究所的评论）','b2'),
        ) );

        $gold->add_field(array(
            'name' => __('关注或被关注','b2'),
            'id'      => 'credit_follow',
            'type'    => 'text',
            'default'=>self::$default_settings['credit_follow'],
            'desc'=>__('奖励对象：点击关注的人或被关注的人，取消关注会扣除相应的积分。默认5分。','b2'),
        ) );

        $gold->add_field(array(
            'name' => __('文章被点赞','b2'),
            'id'      => 'credit_post_up',
            'type'    => 'text',
            'default'=>self::$default_settings['credit_post_up'],
            'desc'=>__('奖励对象：文章作者，如果取消点赞回扣除相应的积分。默认10分。','b2'),
        ) );

        $gold->add_field(array(
            'name' => __('发布快讯','b2'),
            'id'      => 'credit_newsflashes',
            'type'    => 'text',
            'default'=>self::$default_settings['credit_newsflashes'],
            'desc'=>__('发布快讯，并且已经审核通过，奖励对象：发布快讯的人。默认20分。','b2'),
        ) );

        $gold->add_field(array(
            'name' => __('签到','b2'),
            'id'      => 'credit_qd',
            'type'    => 'text',
            'default'=>self::$default_settings['credit_qd'],
            'desc'=>__('奖励对象：当前登录用户，登录用户每日签到将会随机获得积分，如果是固定值请使用 xx-xx 例如 100-100（中间横杠不可缺失）。','b2'),
        ) );

        $gold->add_field(array(
            'name' => __('签到填坑倍数','b2'),
            'id'      => 'tk_bs',
            'type'    => 'text',
            'default'=>self::$default_settings['tk_bs'],
            'desc'=>sprintf(__('请参考%s填坑说明%s','b2'),'<a href="'.b2_get_custom_page_url('mission').'/today" target="_blank">','</a>'),
        ) );
    }

    public static function task_settings(){
        $task = new_cmb2_box(array(
            'id'           => 'b2_task_options_page',
            'tab_title'    => __('任务设置','b2'), 
            'object_types' => array( 'options-page' ),
            'option_key'      => 'b2_normal_task',
            'parent_slug'     => 'admin.php?page=b2_normal_main',
            'tab_group'    => 'b2_normal_options',
        ));

        foreach(b2_task_arg() as $k=>$v){
            if($k === 'task_post'){
                $task->add_field(array(
                    'name' => $v['name'].__('任务次数'),
                    'id'      => $k,
                    'type'    => 'text',
                    'default'=>$v['times'],
                    'before_row'=>'<h2>每日任务次数</h2><p>1、如果不启用此任务，请将任务数量设置为0，此时用户奖励积分的次数将没有限制</p><p>2、奖励的金额是财富设置中的积分金额</p><p>3、超过这些次数以后将不再增加积分</p><p>4、每天重置次数</p>'
                ));
            }else{
                $task->add_field(array(
                    'name' => $v['name'].__('任务次数'),
                    'id'      => $k,
                    'type'    => 'text',
                    'default'=>$v['times'],
                ));
            }
        }

        foreach (b2_task_user_arg() as $key => $value) {
            if($key === 'task_user_qq'){
                $task->add_field(array(
                    'name' => $value['name'].__('奖励积分'),
                    'id'      => $key,
                    'type'    => 'text',
                    'default'=>$value['credit'],
                    'before_row'=>'<h2>新手任务积分奖励</h2><p>1、如果不启用此任务，请将积分奖励设置为0</p>'
                ));
            }else{
                $task->add_field(array(
                    'name' => $value['name'].__('奖励积分'),
                    'id'      => $key,
                    'type'    => 'text',
                    'default'=>$value['credit'],
                ));
            }
        }
    }

    public static function weixin_settings(){
        $weixin = new_cmb2_box(array(
            'id'           => 'b2_weixin_options_page',
            'tab_title'    => __('微信设置','b2'), 
            'object_types' => array( 'options-page' ),
            'option_key'      => 'b2_normal_weixin',
            'parent_slug'     => 'admin.php?page=b2_normal_main',
            'tab_group'    => 'b2_normal_options',
        ));

        $weixin->add_field(array(
            'name' => __('微信公众号appid','b2'),
            'id'      => 'weixin_appid',
            'type'    => 'text',
            'desc'=>__('进入微信公众平台（服务号）->左侧菜单最下面->基本配置->开发者ID(AppID)','b2'),
            'before_row'=>'<h2>'.__('微信设置','b2').'</h2><p>'.sprintf(__('填写此信息，您的网站将和微信公众号深度整合（%s必须为微信服务号，订阅号没有此功能）%s'),'<b class="red">','</b>').'<p>'
        ) );

        $weixin->add_field(array(
            'name' => __('微信公众号appsecret','b2'),
            'id'      => 'weixin_appsecret',
            'type'    => 'text',
            'desc'=>__('进入微信公众平台（服务号）->左侧菜单最下面->基本配置->开发者密码(AppSecret)','b2'),
            'after_row'=>'
            <h2>以上两个获取完成以后，请按照下面的步骤配置公众号：</h2>
            <p>1、微信公众号后台左侧菜单最下面->基本配置->IP白名单中将自己服务器的IP加入白名单</p>
            <p>2、微信公众号后台左侧菜单->公众号设置->功能设置中，请将业务域名、JS接口安全域名、网页授权域名三项按照要求填写进去，网址为您的站点域名</p>
            '
        ) );

        $weixin->add_field(array(
            'name' => __('Token','b2'),
            'id'      => 'weixin_token',
            'type'    => 'text',
            'before_row'=>'
            <hr><h2>微信公众号服务器配置</h2>
            <p>请进入微信公众号后台->左侧菜单->基本配置->服务器配置，然后按照下图所示进行填写</p>
            '
        ) );

        $weixin->add_field(array(
            'name' => __('EncodingAESKey','b2'),
            'id'      => 'weixin_encodingaeskey',
            'type'    => 'text',
            'after_row'=>'<p>设置方法参考如下：</p><p><img src="'.B2_THEME_URI.'/Assets/admin/images/weixservers.png'.'"></p><p>如果提交验证token失败，请检查url是否输入错误</p><p class="red">公众号后台提交此项设置以后一定记得点击启用按钮</p>'
        ) );
    }

    public static function weixin_menu(){
        $weixin = new_cmb2_box(array(
            'id'           => 'b2_weixin_menu_options_page',
            'tab_title'    => __('微信公众号菜单设置','b2'), 
            'object_types' => array( 'options-page' ),
            'option_key'      => 'b2_normal_weixin_menu',
            'parent_slug'     => 'admin.php?page=b2_normal_main',
            'tab_group'    => 'b2_normal_options',
            'display_cb'      => array(__CLASS__,'list_option_page_cb'),
        ));

        $weixin->add_field(array(
            'name' => __('微信菜单Json数据','b2'),
            'id'      => 'weixin_menu',
            'type'    => 'textarea',
            'before_row'=>'<h2>微信菜单设置</h2>
            <p>1、请注意，要使用此功能，必须开通了微信服务号，并且 <a href="'.admin_url().'/admin.php?page=b2_normal_weixin" target="_blank">微信设置</a> 中的各项设置填写完毕，并且微信后台启用了服务器配置。</p>
            <p>2、进入 <a href="https://wei.jiept.com/" target="_blank">微信菜单设置页面</a> 根据您的需求将菜单设置好，然后将生成的 json 数据复制到下面的设置项中，保存即可。</p>
            <p>3、修改菜单可能不会立刻生效，大概有5分钟的缓存期。</p>',
            'after_row'=>'<h2>没经验的朋友请参考下图：<h2><p><a href="https://wei.jiept.com/" target="_blank">https://wei.jiept.com/</a></p><p><img src="'.B2_THEME_URI.'/Assets/admin/images/weixinmenu.png'.'"></p>'
        ) ); 
    }
}